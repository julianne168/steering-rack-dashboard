#!/usr/bin/env python3
"""下载钉钉转向器关键词库的关键词1/2/3列。"""
import json,subprocess
from pathlib import Path
import pandas as pd
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'03_原数据').is_dir())
cmd=['dws','sheet','range','read','--node','Gl6Pm2Db8D3Dl5K7cLm4xkpGJxLq0Ee4','--sheet-id','kgqie6hm','--range','M1:O500','--format','json']
r=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',check=True); payload=json.loads(r.stdout)
rows=[[c.get('value','') for c in row] for row in payload['cells']]
pd.DataFrame(rows[1:],columns=['关键词1','关键词2','关键词3']).to_csv(ROOT/'03_原数据/模块F_转向器关键词库.csv',index=False,encoding='utf-8-sig')
print(f'关键词={len(rows)-1}')
