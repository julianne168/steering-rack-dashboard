#!/usr/bin/env python3
"""模块 A 第二步：读取 Finance 原始 CSV，按 ASIN 计算环比、TACOS 与预警。

不访问任何外部数据源。默认读取原数据目录中上周 vs 上上周的 Finance 原始数据，
结果保存到资料包根目录的“分析结果”文件夹。
"""
import argparse
import csv
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent


def find_package_root():
    """兼容旧资料包的单层/双层目录结构，定位实际含“原数据”的根目录。"""
    for ancestor in SCRIPT_DIR.parents:
        if (ancestor / "03_原数据").is_dir():
            return ancestor
    # 旧目录可能在外层资料包下再套一层同名资料包。
    outer_root = SCRIPT_DIR.parents[3]
    for candidate in outer_root.iterdir():
        if candidate.is_dir() and (candidate / "03_原数据").is_dir():
            return candidate
    return outer_root


PACKAGE_ROOT = find_package_root()
DEFAULT_INPUT_DIR = PACKAGE_ROOT / "03_原数据"
DEFAULT_OUTPUT_DIR = PACKAGE_ROOT / "04_分析结果"


def default_weeks(reference=None):
    today = reference or date.today()
    latest_sunday = today - timedelta(days=today.weekday() + 1)
    latest_monday = latest_sunday - timedelta(days=6)
    previous_monday = latest_monday - timedelta(days=7)
    to_iso = lambda day: f"{day.isocalendar().year}-W{day.isocalendar().week:02d}"
    return to_iso(latest_monday), to_iso(previous_monday)


def num(value):
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def change(current, previous):
    if previous == 0:
        return "" if current == 0 else "N/A"
    return round((current - previous) / previous * 100, 2)


def main():
    parser = argparse.ArgumentParser(description="模块 A ASIN 周环比预警")
    parser.add_argument("--week", help="比较周；默认最近完整自然周")
    parser.add_argument("--prev", help="对比周；默认比较周的前一自然周")
    parser.add_argument("--input", help="Finance 原始 CSV；默认按周窗口自动定位")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    args = parser.parse_args()
    default_week, default_prev = default_weeks()
    week, prev = args.week or default_week, args.prev or default_prev
    source = Path(args.input) if args.input else DEFAULT_INPUT_DIR / f"模块A_Finance原始数据_{week}_vs_{prev}.csv"
    if not source.exists():
        raise SystemExit(f"未找到 Finance 原始数据：{source}。请先运行模块A_Finance原数据拉取.py")

    aggregate = defaultdict(lambda: {"skus": set(), "qty": 0.0, "sales": 0.0, "profit": 0.0, "sp": 0.0, "sd": 0.0, "sb": 0.0})
    with open(source, encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            current_week, asin = str(row.get("年周", "")), str(row.get("ASIN", "")).strip()
            if current_week not in {week, prev} or not asin.startswith("B0"):
                continue
            entry = aggregate[(current_week, asin)]
            entry["skus"].add(str(row.get("SKU", "")).strip())
            entry["qty"] += num(row.get("出库销量"))
            entry["sales"] += num(row.get("出库销售额"))
            entry["profit"] += num(row.get("毛利润-实际"))
            entry["sp"] += num(row.get("广告花费-SP"))
            entry["sd"] += num(row.get("广告花费-SD"))
            entry["sb"] += num(row.get("广告花费-SB"))

    monitor = []
    for asin in sorted({asin for _, asin in aggregate}):
        current, previous = aggregate[(week, asin)], aggregate[(prev, asin)]
        spend, prev_spend = current["sp"] + current["sd"] + current["sb"], previous["sp"] + previous["sd"] + previous["sb"]
        tacos = spend / current["sales"] * 100 if current["sales"] else None
        prev_tacos = prev_spend / previous["sales"] * 100 if previous["sales"] else None
        margin = current["profit"] / current["sales"] * 100 if current["sales"] else None
        prev_margin = previous["profit"] / previous["sales"] * 100 if previous["sales"] else None
        qty_change, sales_change = change(current["qty"], previous["qty"]), change(current["sales"], previous["sales"])
        tacos_change = change(tacos, prev_tacos) if tacos is not None and prev_tacos is not None else ""
        flags = []
        if isinstance(qty_change, (int, float)) and qty_change <= -20: flags.append("单量下滑≥20%")
        if isinstance(sales_change, (int, float)) and sales_change <= -20: flags.append("销售额下滑≥20%")
        if isinstance(tacos_change, (int, float)) and tacos_change >= 30: flags.append("TACOS上升≥30%")
        monitor.append({"ASIN": asin, "SKU集合": "|".join(sorted(current["skus"] | previous["skus"])), "上周": week, "上上周": prev,
                        "上周单量": round(current["qty"], 2), "上上周单量": round(previous["qty"], 2), "单量环比%": qty_change,
                        "上周销售额": round(current["sales"], 2), "上上周销售额": round(previous["sales"], 2), "销售额环比%": sales_change,
                        "上周广告花费": round(spend, 2), "上上周广告花费": round(prev_spend, 2),
                        "上周毛利润-实际": round(current["profit"], 2), "上上周毛利润-实际": round(previous["profit"], 2),
                        "上周毛利率%": round(margin, 2) if margin is not None else "", "上上周毛利率%": round(prev_margin, 2) if prev_margin is not None else "", "毛利率环比%": change(margin, prev_margin) if margin is not None and prev_margin is not None else "",
                        "上周TACOS%": round(tacos, 2) if tacos is not None else "", "上上周TACOS%": round(prev_tacos, 2) if prev_tacos is not None else "", "TACOS环比%": tacos_change,
                        "预警标记": "；".join(flags), "需补充广告指标": "曝光/点击/CTR/CVR/ACOS/ROAS/活动清单"})

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"模块A_ASIN周环比监控表_{week}_vs_{prev}.csv"
    fields = list(monitor[0]) if monitor else ["ASIN", "预警标记"]
    with open(output, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(monitor)
    print(f"监控结果已保存：{output}；预警 {sum(bool(row['预警标记']) for row in monitor)} 个 ASIN")


if __name__ == "__main__":
    main()
