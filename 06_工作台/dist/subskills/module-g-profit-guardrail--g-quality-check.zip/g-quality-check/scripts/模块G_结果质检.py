#!/usr/bin/env python3
"""模块G结果质检：检查关键成本字段、ACOS范围和数据缺失。"""
import argparse, csv, sys
from pathlib import Path

def num(v):
    try: return float(v)
    except (TypeError, ValueError): return None

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--input", required=True); args=ap.parse_args()
    with open(args.input, encoding="utf-8-sig", newline="") as f: rows=list(csv.DictReader(f))
    errors=[]
    for r in rows:
        asin=r.get("ASIN", "")
        if not asin.startswith("B0"): errors.append(f"{asin}: 非B0 ASIN")
        for col in ("平衡ACOS%", "目标ACOS%", "当前ACOS%"):
            value=num(r.get(col))
            if value is not None and not -100 <= value <= 100: errors.append(f"{asin}: {col}超出[-100,100]")
        if num(r.get("出库销售额")) and r.get("平衡ACOS%", "") == "": errors.append(f"{asin}: 有销售额但缺少平衡ACOS")
    print(f"质检：{len(rows)} 行，异常 {len(errors)} 项")
    for error in errors[:30]: print("-", error)
    sys.exit(1 if errors else 0)

if __name__ == "__main__": main()
