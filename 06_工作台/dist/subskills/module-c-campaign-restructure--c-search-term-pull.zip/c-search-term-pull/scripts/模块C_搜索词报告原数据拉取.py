#!/usr/bin/env python3
"""模块C：拉取多ASIN活动的搜索词报告原始数据。

数据源：dw.dwi_ad_search_term。按活动ID、ASIN、搜索词保留30天日粒度数据，
用于核验“某ASIN的适配词实际流量落在另一不适配ASIN”这一真实冲突。
数据库凭据只从同目录 .env 或系统环境变量 DB_* 读取。
"""
import argparse
import os
from datetime import date, timedelta
from pathlib import Path
import pandas as pd
import pymysql

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / "03_原数据").is_dir())

def load_env():
    p = HERE / ".env"
    if p.is_file():
        for line in p.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

def connection():
    load_env()
    if not os.getenv("DB_PASSWORD"):
        raise RuntimeError("未配置 DB_PASSWORD：请在本目录 .env 或系统环境变量中设置。")
    return pymysql.connect(host=os.getenv("DB_HOST"), port=int(os.getenv("DB_PORT", "9030")),
        user=os.getenv("DB_USER"), password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME", "dw"), charset="utf8mb4", connect_timeout=30, read_timeout=300)

def latest_week_activity_ids(path: Path):
    d = pd.read_excel(path, sheet_name="ASIN对应活动清单", usecols=["年周", "活动ID"])
    week = sorted(d["年周"].dropna().astype(str).unique())[-1]
    return week, sorted(d.loc[d["年周"].astype(str).eq(week), "活动ID"].dropna().astype(str).unique())

def main():
    p = argparse.ArgumentParser(description="模块C搜索词报告原数据拉取")
    p.add_argument("--activity", default=str(ROOT / "03_原数据/模块A_领星ASIN广告指标周环比表.xlsx"))
    p.add_argument("--start", default=(date.today() - timedelta(days=29)).isoformat())
    p.add_argument("--end", default=date.today().isoformat())
    p.add_argument("--output", default=str(ROOT / "03_原数据/模块C_搜索词报告_近30天.csv"))
    a = p.parse_args()
    week, ids = latest_week_activity_ids(Path(a.activity))
    sql = """SELECT period_id_d AS 日期, shop_code AS 店铺, campaign_id AS 活动ID,
        campaign_name AS 活动名称, platform_sale_code AS ASIN, adgroup_id AS 广告组ID,
        ad_group_name AS 广告组名称, targeting_type AS 投放方式, targeting AS 投放词,
        match_type AS 匹配类型, search_term AS 搜索词, impressions AS 曝光, clicks AS 点击,
        spend AS 广告花费, total_orders AS 广告订单, total_sales AS 广告销售额
        FROM dw.dwi_ad_search_term
        WHERE platform='AMAZON' AND operation_classification='转向器'
          AND period_id_d BETWEEN %s AND %s AND campaign_id IN ({})"""
    pieces = []
    with connection() as con:
        for start in range(0, len(ids), 500):
            batch = ids[start:start + 500]
            pieces.append(pd.read_sql_query(sql.format(",".join(["%s"] * len(batch))), con,
                params=[a.start, a.end, *batch]))
    data = pd.concat(pieces, ignore_index=True) if pieces else pd.DataFrame()
    output = Path(a.output); output.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(output, index=False, encoding="utf-8-sig")
    print(f"活动统计周={week}；活动数={len(ids)}；搜索词明细={len(data)}；输出={output}")

if __name__ == "__main__":
    main()
