#!/usr/bin/env python3
"""模块F：从BI数仓 dwi_ad_search_term 拉取近30天转向器搜索词原数据。"""
import os
from datetime import date,timedelta
from pathlib import Path
import pandas as pd,pymysql
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'03_原数据').is_dir())
def main():
 p=HERE/'.env'
 for x in p.read_text(encoding='utf-8').splitlines() if p.is_file() else []:
  if '=' in x and not x.lstrip().startswith('#'):
   k,v=x.split('=',1);os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))
 start,end=(date.today()-timedelta(days=29)).isoformat(),date.today().isoformat()
 sql="""SELECT period_id_d AS 日期,shop_code AS 店铺,campaign_id AS 活动ID,campaign_name AS 活动名称,
 platform_sale_code AS ASIN,adgroup_id AS 广告组ID,ad_group_name AS 广告组名称,targeting AS 投放词,
 targeting_type AS 投放方式,match_type AS 匹配类型,search_term AS 搜索词,impressions AS 曝光,clicks AS 点击,
 spend AS 广告花费,total_orders AS 广告订单,total_sales AS 广告销售额
 FROM dw.dwi_ad_search_term WHERE platform='AMAZON' AND operation_classification='转向器' AND period_id_d BETWEEN %s AND %s"""
 c=pymysql.connect(host=os.environ['DB_HOST'],port=int(os.environ.get('DB_PORT','9030')),user=os.environ['DB_USER'],password=os.environ['DB_PASSWORD'],database='dw',charset='utf8mb4',read_timeout=300)
 d=pd.read_sql_query(sql,c,params=[start,end]);c.close();out=ROOT/'03_原数据/模块F_搜索词报告_近30天.csv';d.to_csv(out,index=False,encoding='utf-8-sig');print(f'{start}至{end}：{len(d)}条；{out}')
if __name__=='__main__':main()
