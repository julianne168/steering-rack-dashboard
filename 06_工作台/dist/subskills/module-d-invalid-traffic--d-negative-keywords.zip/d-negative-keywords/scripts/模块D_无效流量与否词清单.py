#!/usr/bin/env python3
"""模块D：纯浪费词+适配外词，输出待模块E校验的否词清单。"""
import re
from pathlib import Path
import pandas as pd
HERE=Path(__file__).resolve().parent; ROOT=next(p for p in HERE.parents if (p/'03_原数据').is_dir())
def norm(x):return re.sub(r'\s+',' ',str(x).lower().replace('-',' ')).strip()
def main():
 st=pd.read_csv(ROOT/'03_原数据/模块D_搜索词报告_近7天.csv',encoding='utf-8-sig')
 fit=pd.read_csv(ROOT/'03_原数据/模块C_转向器ASIN适配原始数据.csv',encoding='utf-8-sig')
 for c in ['曝光','点击','广告花费','广告订单','广告销售额']:st[c]=pd.to_numeric(st[c],errors='coerce').fillna(0)
 fit['ASIN']=fit['ASIN'].astype(str); fit['品牌']=fit['品牌'].map(norm);fit['车型']=fit['车型'].map(norm);fit['年份']=fit['年份'].fillna('').astype(str)
 profile={a:list(g[['品牌','车型','年份']].drop_duplicates().itertuples(index=False,name=None)) for a,g in fit.groupby('ASIN')}
 all_pairs=set((a,b) for rows in profile.values() for a,b,_ in rows if a and b)
 all_brands=set(a for a,_,_ in [x for rows in profile.values() for x in rows] if a)
 agg=st.groupby(['活动ID','活动名称','ASIN','广告组ID','广告组名称','搜索词'],dropna=False)[['曝光','点击','广告花费','广告订单','广告销售额']].sum().reset_index()
 rows=[]
 for r in agg.itertuples(index=False):
  term=norm(r.搜索词); asin=str(r.ASIN); years=set(re.findall(r'(?<!\d)(?:19|20)\d{2}(?!\d)',term)); rec=profile.get(asin,[])
  contains_core=('rack and pinion' in term or 'steering rack' in term)
  term_pairs={(b,m) for b,m in all_pairs if b in term and m in term}
  brands={b for b in all_brands if b in term}
  compatible=False
  for b,m,y in rec:
   if b in term and m in term and (not years or not y or y in years):compatible=True
  invalid=''
  if contains_core and term_pairs and not compatible:invalid='不相关品牌/车型'
  elif contains_core and brands and not compatible:invalid='不相关品牌'
  elif contains_core and any(b in term and m in term and years and y and y not in years for b,m,y in rec):invalid='适配外年份'
  waste=r.广告花费>50 and r.广告订单==0
  if not waste and not invalid:continue
  typ='；'.join(x for x in (['纯浪费词'] if waste else [])+[invalid] if x)
  layer='L2活动级否定' if invalid else 'L3广告组级否定'
  rows.append({'搜索词':r.搜索词,'广告活动':r.活动名称,'活动ID':r.活动ID,'ASIN':asin,'广告组ID':r.广告组ID,'广告组名称':r.广告组名称,'判定类型':typ,'应用层级':layer,'曝光':r.曝光,'点击':r.点击,'花费':round(r.广告花费,2),'订单':r.广告订单,'销售额':round(r.广告销售额,2),'来源报告周期':'近7天','处理状态':'待模块E校验'})
 out=ROOT/'04_分析结果/模块D_否词清单.csv';pd.DataFrame(rows).to_csv(out,index=False,encoding='utf-8-sig');print(f'搜索词={len(agg)}；待否={len(rows)}；{out}')
if __name__=='__main__':main()
