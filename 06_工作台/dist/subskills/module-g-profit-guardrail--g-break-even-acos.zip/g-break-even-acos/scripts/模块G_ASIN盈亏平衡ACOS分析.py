#!/usr/bin/env python3
"""模块G：从损益成本原数据计算ASIN盈亏平衡ACOS、目标ACOS及当前状态。"""
import argparse
import csv
from collections import defaultdict
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = next((p for p in SCRIPT_DIR.parents if (p / "04_分析结果").is_dir()), SCRIPT_DIR.parents[3])

def number(value):
    try: return float(str(value).replace(",", "").replace("%", "") or 0)
    except (TypeError, ValueError): return 0.0

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))

def pct(value): return "" if value is None else round(value * 100, 2)

def main():
    ap = argparse.ArgumentParser(description="模块G ASIN盈亏平衡ACOS分析")
    ap.add_argument("--input", required=True, help="模块G_损益成本原始数据_YYYYMM.csv")
    ap.add_argument("--target-buffer-pp", type=float, default=5.0, help="目标ACOS比平衡线低的百分点，默认5")
    ap.add_argument("--output", default=str(ROOT / "04_分析结果/模块G_ASIN盈亏平衡表.csv"))
    args = ap.parse_args()
    grouped = defaultdict(lambda: defaultdict(float))
    texts = {}
    numeric_fields = ["出库销量", "出库销售额", "采购成本-实际", "头程成本-实际", "佣金", "税费", "仓储费", "尾程费", "广告花费-SP", "广告花费-SD", "广告花费-SB"]
    for row in read(args.input):
        asin = (row.get("ASIN") or "").strip().upper()
        if not asin: continue
        texts[asin] = {"年月": row.get("年月", ""), "SKU": row.get("SKU", "")}
        for field in numeric_fields: grouped[asin][field] += number(row.get(field))

    rows = []
    for asin, v in grouped.items():
        sales, qty = v["出库销售额"], v["出库销量"]
        if sales <= 0 or qty <= 0:
            status, breakeven, target, current, conservative = "数据不足", None, None, None, None
        else:
            # 主线严格采用框架公式；佣金优先采用BI实际commission_m，无值时才按20.5%兜底。
            commission = abs(v["佣金"]) if v["佣金"] else sales * 0.205
            procurement, first_leg = abs(v["采购成本-实际"]), abs(v["头程成本-实际"])
            tax, storage = abs(v["税费"]), abs(v["仓储费"])
            coupon_reserve = sales * 0.05
            ad_spend = abs(v["广告花费-SP"]) + abs(v["广告花费-SD"]) + abs(v["广告花费-SB"])
            variable_cost = procurement + first_leg + commission + tax + storage + coupon_reserve
            breakeven = (sales - variable_cost) / sales
            conservative = (sales - variable_cost - abs(v["尾程费"])) / sales
            target = max(0.0, breakeven - args.target_buffer_pp / 100)
            current = ad_spend / sales
            status = "可增投" if current < target else ("接近平衡线" if current < breakeven else "高于平衡线，需优化")
        row = {
            "年月": texts[asin]["年月"], "ASIN": asin, "SKU": texts[asin]["SKU"], "售价": round(sales / qty, 2) if sales and qty else "",
            "出库销量": round(qty, 2), "出库销售额": round(sales, 2), "采购成本": round(abs(v["采购成本-实际"]), 2),
            "头程": round(abs(v["头程成本-实际"]), 2), "佣金": round(abs(v["佣金"]) if v["佣金"] else sales * 0.205, 2),
            "税费": round(abs(v["税费"]), 2), "仓储费": round(abs(v["仓储费"]), 2), "Coupon预留(5%)": round(sales * 0.05, 2),
            "尾程费(参考未计主线)": round(abs(v["尾程费"]), 2), "广告花费": round(abs(v["广告花费-SP"]) + abs(v["广告花费-SD"]) + abs(v["广告花费-SB"]), 2),
            "平衡ACOS%": pct(breakeven), "目标ACOS%": pct(target), "当前ACOS%": pct(current), "含尾程保守平衡ACOS%": pct(conservative), "状态": status,
        }
        rows.append(row)
    rows.sort(key=lambda r: number(r["出库销售额"]), reverse=True)
    out = Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
    fields = ["年月", "ASIN", "SKU", "售价", "出库销量", "出库销售额", "采购成本", "头程", "佣金", "税费", "仓储费", "Coupon预留(5%)", "尾程费(参考未计主线)", "广告花费", "平衡ACOS%", "目标ACOS%", "当前ACOS%", "含尾程保守平衡ACOS%", "状态"]
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    print(f"已输出 {len(rows)} 个ASIN：{out}")

if __name__ == "__main__": main()
