#!/usr/bin/env python3
"""模块F：识别有订单但未被当前投放词精确覆盖的机会词。"""
import re
from pathlib import Path
import pandas as pd
HERE=Path(__file__).resolve().parent;ROOT=next(p for p in HERE.parents if (p/'03_原数据').is_dir())
def norm(x):return re.sub(r'\s+',' ',str(x).lower()).strip()
def main():
 d=pd.read_csv(ROOT/'03_原数据/模块F_搜索词报告_近30天.csv',encoding='utf-8-sig').fillna('')
 kw=pd.read_csv(ROOT/'03_原数据/模块F_转向器关键词库.csv',encoding='utf-8-sig').fillna('')
 e=pd.read_csv(ROOT/'04_分析结果/模块E_否词校验表.csv',encoding='utf-8-sig').fillna('')
 for c in ['曝光','点击','广告花费','广告订单','广告销售额']:d[c]=pd.to_numeric(d[c],errors='coerce').fillna(0)
 d['搜索词标准']=d['搜索词'].map(norm);d['投放词标准']=d['投放词'].map(norm)
 # 同一ASIN任一广告组已精准投放该词，即不作为“未投放”机会词。
 targets=d.groupby('ASIN')['投放词标准'].apply(lambda x:set(v for v in x if v and v not in {'auto','close match','loose match','substitutes','complements'})).to_dict()
 library=set(norm(v) for v in kw[['关键词1','关键词2','关键词3']].astype(str).values.flatten() if norm(v))
 negatives=set(norm(v) for v in e.loc[e['可否决'].astype(str).str.startswith('可否定'),'待否词'])
 g=d.groupby(['ASIN','搜索词标准'],dropna=False).agg(搜索词=('搜索词','first'),广告活动=('活动名称',lambda x:'；'.join(sorted(set(map(str,x))))),
  曝光=('曝光','sum'),点击=('点击','sum'),花费=('广告花费','sum'),订单=('广告订单','sum'),销售额=('广告销售额','sum')).reset_index()
 rows=[]
 for r in g.itertuples(index=False):
  if r.订单<=0 or r.搜索词标准 in targets.get(r.ASIN,set()) or r.搜索词标准 in library or r.搜索词标准 in negatives:continue
  rows.append({'词':r.搜索词,'类型':'机会词（有出单未覆盖）','来源':'搜索词报告','来源活动':r.广告活动,'搜索量/曝光':r.曝光,'点击':r.点击,'订单':r.订单,'销售额':round(r.销售额,2),'花费':round(r.花费,2),'预估竞争度':'待补ABA搜索量/排名','推荐ASIN':r.ASIN,'建议匹配类型':'精准' if r.订单>=2 else '词组','建议动作':'新建对应ASIN关键词投放，7天复核','处理状态':'待运营确认'})
 out=ROOT/'04_分析结果/模块F_潜力词清单.csv';pd.DataFrame(rows).sort_values(['订单','销售额'],ascending=False).to_csv(out,index=False,encoding='utf-8-sig');print(f'聚合词={len(g)}；机会词={len(rows)}；{out}')
if __name__=='__main__':main()
