#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从 BI MCP 拉取损益数据，生成按商品编码和 ASIN 汇总的毛利率报表。"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


DEFAULT_ENDPOINT = "https://higress.suncentgroup.com/mcp-servers/bi-getdata-finance"
TOKEN_ENV = "SUNCENT_BI_TOKEN"
QUERY_TOOL = "query_smartbi_data"

RAW_FIELDS = [
    "sales_qty_m", "sales_amount_m", "gross_profit_real_m",
    "sales_purchase_amount_real_m", "sales_first_leg_amount_real_m",
    "courier_fee_m", "推广合计", "promotion_m", "refund_amount_m",
    "storage_fee_m", "shop_fee_return_m", "commission_m", "tax_fee_m",
]
HEADERS = [
    "商品编码", "ASIN", "销量", "销售额", "毛利率", "材料占比", "头程占比",
    "尾程占比", "推广合计占比", "促销折扣占比", "退款金额占比", "仓储费占比",
    "库内操作费占比", "佣金占比", "税费占比",
]


def as_number(value: Any) -> float:
    """将 BI 返回的空值或数值文本安全转成数字。"""
    try:
        return float(value) if value not in (None, "") else 0.0
    except (TypeError, ValueError):
        return 0.0


def parse_sse_json(payload: str, request_id: int) -> dict[str, Any]:
    """从 MCP 的 SSE 或普通 JSON 响应中取回指定 JSON-RPC 结果。"""
    payload = payload.strip()
    if payload.startswith("{"):
        message = json.loads(payload)
        if message.get("error"):
            raise RuntimeError(message["error"].get("message", str(message["error"])))
        return message

    messages: list[dict[str, Any]] = []
    for block in payload.replace("\r\n", "\n").split("\n\n"):
        data = "\n".join(line[6:] for line in block.split("\n") if line.startswith("data:"))
        if not data:
            continue
        try:
            messages.append(json.loads(data))
        except json.JSONDecodeError:
            continue
    for message in messages:
        if message.get("id") == request_id:
            if message.get("error"):
                raise RuntimeError(message["error"].get("message", str(message["error"])))
            return message
    raise RuntimeError("BI MCP 未返回对应的 JSON-RPC 结果。")


class StreamableMcpClient:
    """仅使用 Python 标准库实现的 Streamable HTTP MCP 客户端。"""

    def __init__(self, endpoint: str, token: str) -> None:
        self.endpoint = endpoint
        self.token = token
        self.session_id: str | None = None
        self.next_id = 1

    def _post(self, message: dict[str, Any], include_session: bool = True) -> tuple[dict[str, Any], Any]:
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json, text/event-stream",
            "Content-Type": "application/json",
            "MCP-Protocol-Version": "2025-03-26",
        }
        if include_session and self.session_id:
            headers["Mcp-Session-Id"] = self.session_id
        request = urllib.request.Request(
            self.endpoint,
            data=json.dumps(message, ensure_ascii=False).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                text = response.read().decode("utf-8")
                return parse_sse_json(text, message.get("id", -1)), response.headers
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"BI MCP 请求失败（HTTP {exc.code}）：{detail}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"无法连接 BI MCP：{exc.reason}") from exc

    def connect(self) -> None:
        message = {
            "jsonrpc": "2.0", "id": self.next_id, "method": "initialize",
            "params": {
                "protocolVersion": "2025-03-26", "capabilities": {},
                "clientInfo": {"name": "asin-profit-summary", "version": "1.0"},
            },
        }
        self.next_id += 1
        _, headers = self._post(message, include_session=False)
        self.session_id = headers.get("Mcp-Session-Id")
        if not self.session_id:
            raise RuntimeError("BI MCP 初始化未返回 Mcp-Session-Id。")
        notification = {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}
        self._post(notification)

    def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        message = {
            "jsonrpc": "2.0", "id": self.next_id, "method": "tools/call",
            "params": {"name": name, "arguments": arguments},
        }
        self.next_id += 1
        response, _ = self._post(message)
        return response["result"]


def unwrap_bi_result(tool_result: dict[str, Any]) -> dict[str, Any]:
    """兼容 BI MCP 工具返回的 content/result 多层包装。"""
    content = tool_result.get("content", [])
    if not content:
        raise RuntimeError("BI MCP 返回为空。")
    text = next((item.get("text") for item in content if item.get("type") == "text"), None)
    if not text:
        raise RuntimeError("BI MCP 未返回文本数据。")
    outer = json.loads(text)
    result = outer.get("result", outer)
    return json.loads(result) if isinstance(result, str) else result


def fetch_raw_data(month: str, classification: str, platform: str, endpoint: str) -> dict[str, Any]:
    token = os.getenv(TOKEN_ENV)
    if not token:
        raise RuntimeError(f"未找到环境变量 {TOKEN_ENV}。请先设置 BI Token 后再运行。")
    client = StreamableMcpClient(endpoint, token)
    client.connect()
    arguments = {
        "dimensions": ["sku", "platform_sale_code"],
        "measures": RAW_FIELDS,
        "filters": [
            {"name": "period_id_m", "operation": "EQUALS", "values": [month]},
            {"name": "platform2", "operation": "EQUALS", "values": [platform]},
            {"name": "operation_classification2", "operation": "EQUALS", "values": [classification]},
        ],
        "limit": -1,
    }
    return unwrap_bi_result(client.call_tool(QUERY_TOOL, arguments))


def aggregate(raw: dict[str, Any]) -> list[list[Any]]:
    totals: dict[tuple[str, str], list[float]] = defaultdict(lambda: [0.0] * len(RAW_FIELDS))
    for record in raw.get("data", []):
        sku = str(record.get("sku") or "").strip()
        asin = str(record.get("platform_sale_code") or "").strip()
        values = [as_number(record.get(field)) for field in RAW_FIELDS]
        if not sku or not asin or values[1] == 0:
            continue
        bucket = totals[(sku, asin)]
        for index, value in enumerate(values):
            bucket[index] += value

    summary: list[list[Any]] = []
    for (sku, asin), values in totals.items():
        qty, sales, gross, material, first_leg, last_leg, promotion, discount, refund, storage, handling, commission, tax = values
        if sales == 0:
            continue
        rate = lambda amount: amount / sales
        summary.append([
            sku, asin, qty, sales, rate(gross), rate(material), rate(first_leg), rate(last_leg),
            rate(promotion), rate(discount), rate(refund), rate(storage), rate(handling),
            rate(commission), rate(tax),
        ])
    return sorted(summary, key=lambda row: row[3], reverse=True)


def write_excel(rows: list[list[Any]], month: str, classification: str, platform: str, output: Path) -> None:
    book = Workbook()
    sheet = book.active
    sheet.title = "ASIN汇总"
    sheet.sheet_view.showGridLines = False
    sheet["A2"] = f"{month[:4]}年{int(month[4:])}月 {platform} {classification}毛利率 ASIN汇总"
    sheet["A2"].font = Font(name="Arial", size=14, bold=True, color="123B4A")
    sheet["A3"] = f"口径：业务分类={classification}；平台={platform}；年月={month}；按商品编码+ASIN汇总，仅保留销售额非零的组合。共 {len(rows)} 条。"
    sheet["A4"] = "来源：BI MCP“损益明细”。各占比按汇总金额 ÷ 汇总销售额计算。"
    for cell in (sheet["A3"], sheet["A4"]):
        cell.font = Font(name="Arial", size=9, italic=True, color="52616B")

    header_row = 6
    for column, title in enumerate(HEADERS, 1):
        cell = sheet.cell(header_row, column, title)
        cell.font = Font(name="Arial", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="007F9F")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=Side(style="medium", color="007F9F"))
    sheet.row_dimensions[header_row].height = 34

    for row_index, row in enumerate(rows, header_row + 1):
        for column, value in enumerate(row, 1):
            cell = sheet.cell(row_index, column, value)
            cell.font = Font(name="Arial", size=10, color="1F2937")
            cell.alignment = Alignment(vertical="center")
            cell.border = Border(bottom=Side(style="thin", color="C7D9DD"))
        sheet.row_dimensions[row_index].height = 19

    for row in sheet.iter_rows(min_row=header_row + 1, max_row=header_row + len(rows), min_col=3, max_col=3):
        row[0].number_format = '#,##0'
    for row in sheet.iter_rows(min_row=header_row + 1, max_row=header_row + len(rows), min_col=4, max_col=4):
        row[0].number_format = '[$¥-804]#,##0.00;([$¥-804]#,##0.00);-'
    for row in sheet.iter_rows(min_row=header_row + 1, max_row=header_row + len(rows), min_col=5, max_col=15):
        for cell in row:
            cell.number_format = '0.0%;(0.0%);-'
    if rows:
        sheet.conditional_formatting.add(
            f"E{header_row + 1}:E{header_row + len(rows)}",
            CellIsRule(operator="lessThan", formula=["0"], fill=PatternFill("solid", fgColor="FDE2E1"), font=Font(color="B91C1C", bold=True)),
        )
        sheet.auto_filter.ref = f"A{header_row}:O{header_row + len(rows)}"
    sheet.freeze_panes = "C7"
    widths = [18, 16, 10, 14, 12, 12, 12, 12, 14, 14, 14, 12, 14, 12, 12]
    for index, width in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(index)].width = width
    output.parent.mkdir(parents=True, exist_ok=True)
    book.save(output)


def main() -> int:
    parser = argparse.ArgumentParser(description="生成 ASIN 毛利率汇总 Excel。")
    parser.add_argument("--month", default=datetime.now().strftime("%Y%m"), help="年月，例如 202608")
    parser.add_argument("--classification", default="转向器", help="业务分类")
    parser.add_argument("--platform", default="AMAZON", help="平台")
    parser.add_argument("--endpoint", default=DEFAULT_ENDPOINT, help="BI MCP 地址")
    parser.add_argument("--output", default=None, help="输出 Excel 路径")
    parser.add_argument("--output-dir", default=None, help="输出目录；未指定 --output 时在此目录生成默认文件名")
    parser.add_argument("--input-json", help="离线测试：读取已导出的 BI 原始 JSON，不访问 MCP")
    parser.add_argument("--save-raw", help="可选：将本次 BI 原始返回保存为 JSON")
    args = parser.parse_args()
    if len(args.month) != 6 or not args.month.isdigit():
        raise SystemExit("--month 必须为 YYYYMM，例如 202608。")
    default_name = f"{args.month}_{args.platform}_{args.classification}_ASIN毛利率汇总.xlsx"
    output = Path(args.output) if args.output else Path(args.output_dir or ".") / default_name
    raw = json.loads(Path(args.input_json).read_text(encoding="utf-8")) if args.input_json else fetch_raw_data(args.month, args.classification, args.platform, args.endpoint)
    if args.save_raw:
        Path(args.save_raw).write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = aggregate(raw)
    write_excel(rows, args.month, args.classification, args.platform, output)
    print(f"完成：{output.resolve()}（{len(rows)} 条 SKU-ASIN 汇总记录）")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"失败：{exc}", file=sys.stderr)
        raise SystemExit(1)
