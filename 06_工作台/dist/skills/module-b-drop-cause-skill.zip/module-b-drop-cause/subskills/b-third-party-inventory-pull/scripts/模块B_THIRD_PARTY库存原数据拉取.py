#!/usr/bin/env python3
"""模块B：按ASIN汇总 THIRD_PARTY 各仓可售库存（日粒度）。

数据源 dw.dws_stock_product_inventory_snapshot；只取 warehouse_type='THIRD_PARTY'
并汇总 stock_on_sales_qty。不含 FBA、国内仓、PO 与在途数量。
"""
import argparse, csv, os
from datetime import date, timedelta
from pathlib import Path
import pandas as pd
import pymysql

HERE=Path(__file__).resolve().parent
ROOT=next(p for p in HERE.parents if (p/'03_原数据').is_dir())
def env():
    p=HERE/'.env'
    for line in p.read_text(encoding='utf-8').splitlines() if p.is_file() else []:
        if '=' in line and not line.lstrip().startswith('#'):
            k,v=line.split('=',1); os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))
def main():
    ap=argparse.ArgumentParser(description='模块B THIRD_PARTY库存原数据拉取')
    ap.add_argument('--start',default=(date.today()-timedelta(days=28)).isoformat())
    ap.add_argument('--end',default=date.today().isoformat())
    ap.add_argument('--warning-file',default=str(ROOT/'04_分析结果/模块A_ASIN周环比监控表_2026-W35_vs_2026-W34.csv'))
    ap.add_argument('--sales-file',default=str(ROOT/'03_原数据/模块B_ASIN日销量原始数据_2026-08-07_至_2026-09-03.csv'))
    ap.add_argument('--output',default=str(ROOT/'03_原数据/模块B_THIRD_PARTY库存日快照.csv'))
    a=ap.parse_args(); env()
    with open(a.warning_file,encoding='utf-8-sig',newline='') as f:
        asins=sorted({r['ASIN'] for r in csv.DictReader(f) if r.get('预警标记')})
    sales=pd.read_csv(a.sales_file,encoding='utf-8-sig',dtype=str)
    mapping=sales[['ASIN','SKU']].dropna().drop_duplicates()
    mapping=mapping[mapping['ASIN'].isin(asins) & mapping['SKU'].ne('')]
    skus=sorted(mapping['SKU'].unique())
    sql="""SELECT period_id_d AS 日期, sku AS SKU, SUM(COALESCE(stock_on_sales_qty,0)) AS THIRD_PARTY可售库存
    FROM dw.dws_stock_product_inventory_snapshot
    WHERE warehouse_type='THIRD_PARTY' AND sku IN ({}) AND period_id_d BETWEEN %s AND %s
    GROUP BY period_id_d, sku ORDER BY period_id_d, sku"""
    con=pymysql.connect(host=os.environ['DB_HOST'],port=int(os.environ.get('DB_PORT','9030')),user=os.environ['DB_USER'],password=os.environ['DB_PASSWORD'],database='dw',charset='utf8mb4',connect_timeout=30,read_timeout=300)
    frames=[]
    for i in range(0,len(skus),500):
        batch=skus[i:i+500]
        frames.append(pd.read_sql_query(sql.format(','.join(['%s']*len(batch))),con,params=[*batch,a.start,a.end]))
    con.close(); data=pd.concat(frames,ignore_index=True) if frames else pd.DataFrame(columns=['日期','SKU','THIRD_PARTY可售库存'])
    data=data.merge(mapping,on='SKU',how='inner')
    data=data[['日期','ASIN','SKU','THIRD_PARTY可售库存']]
    Path(a.output).parent.mkdir(parents=True,exist_ok=True); data.to_csv(a.output,index=False,encoding='utf-8-sig')
    print(f'ASIN={len(asins)}；商品编码={len(skus)}；库存日记录={len(data)}；输出={a.output}')
if __name__=='__main__': main()
