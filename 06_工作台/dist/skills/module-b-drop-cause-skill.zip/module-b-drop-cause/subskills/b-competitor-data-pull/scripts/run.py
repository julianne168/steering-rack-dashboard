"""在指定工作区运行 模块B_竞对异常原数据拉取.py。"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


CORE_SCRIPT = Path(__file__).with_name('模块B_竞对异常原数据拉取.py')
SLUG = 'b-competitor-data-pull'


def main() -> int:
    parser = argparse.ArgumentParser(
        description="在指定项目工作区运行此子技能；脚本参数请置于 -- 之后。"
    )
    parser.add_argument("--workspace-root", required=True, help="包含 03_原数据 和 04_分析结果 的项目根目录")
    args, script_args = parser.parse_known_args()
    if script_args[:1] == ["--"]:
        script_args = script_args[1:]

    workspace = Path(args.workspace_root).expanduser().resolve()
    if not workspace.is_dir():
        raise SystemExit(f"工作区不存在：{workspace}")
    (workspace / "03_原数据").mkdir(exist_ok=True)
    (workspace / "04_分析结果").mkdir(exist_ok=True)

    stage = workspace / ".xbm-skill-runtime" / SLUG
    entry = stage / CORE_SCRIPT.name
    try:
        stage.mkdir(parents=True, exist_ok=True)
        shutil.copy2(CORE_SCRIPT, entry)
        completed = subprocess.run([sys.executable, str(entry), *script_args], cwd=workspace)
        return completed.returncode
    finally:
        shutil.rmtree(stage, ignore_errors=True)
        runtime_root = stage.parent
        if runtime_root.is_dir() and not any(runtime_root.iterdir()):
            runtime_root.rmdir()


if __name__ == "__main__":
    raise SystemExit(main())
