#!/usr/bin/env python3
"""模块B：通过卖家精灵 MCP 拉取竞对价格、优惠及 Keepa 趋势原数据。

先运行“模块B_竞对异常任务清单.py”生成任务清单；本脚本按去重竞对 ASIN
各调用一次：
  - asin_coupon_trend：历史页面价、Coupon、优惠后实际价格；
  - keepa_info：dealPrice（LD候选）、buyBox/price（BD候选）、BSR。

不保存密钥。认证由本机卖家精灵 MCP 配置负责。运行前需已授权这两个 MCP 工具。
"""
import argparse
import csv
import json
import subprocess
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = next((p for p in SCRIPT_DIR.parents if (p / "03_原数据").is_dir()), SCRIPT_DIR.parents[3])

def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def write_csv(path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader(); writer.writerows(rows)

def call_mcp(tool, args, timeout):
    """返回 MCP data。工具名可通过命令行覆盖，避免把 MCP 服务名写死。"""
    proc = subprocess.run(
        ["mcporter", "call", tool, "--args", json.dumps(args, ensure_ascii=False)],
        capture_output=True, text=True, encoding="utf-8", timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError((proc.stderr or proc.stdout or "MCP 调用失败").strip()[:1000])
    try:
        response = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"MCP 返回不是 JSON：{proc.stdout[:500]}") from exc
    if isinstance(response, dict) and response.get("code") not in (None, "OK", 0, 200):
        raise RuntimeError(str(response.get("message") or response)[:1000])
    return response.get("data", response) if isinstance(response, dict) else response

def as_number(value):
    try: return float(value)
    except (TypeError, ValueError): return None

def parse_day(value):
    return date.fromisoformat(str(value)[:10])

def trend_by_day(points, window_start, window_end):
    """Keepa 变更点转为每日最后有效值；同日短时 dealPrice 单独保留。"""
    by_day = {}
    for point in points or []:
        try:
            day = datetime.fromtimestamp(int(point["timePoint"]) / 1000, tz=timezone.utc).date()
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        if window_start <= day <= window_end:
            by_day[day] = point.get("value")
    result, current = {}, None
    for offset in range((window_end - window_start).days + 1):
        day = window_start + timedelta(days=offset)
        if day in by_day: current = by_day[day]
        result[day] = current
    return result, by_day

def bd_candidate(price_series):
    """低价连续≥7天，且较此前可得的7日均价低≥15%，标为BD候选，不作为官方BD结论。"""
    days = sorted(price_series)
    flags = {day: False for day in days}
    for i in range(7, len(days) - 6):
        low_days = days[i:i + 7]
        if any(price_series[d] is None for d in low_days): continue
        prior = [price_series[days[j]] for j in range(max(0, i - 7), i) if price_series[days[j]] is not None]
        if len(prior) < 3: continue
        baseline = sum(float(x) for x in prior) / len(prior)
        if baseline <= 0: continue
        if all(float(price_series[d]) <= baseline * 0.85 for d in low_days):
            for d in low_days: flags[d] = True
    return flags

def detail_items(task):
    try:
        items = json.loads(task.get("关联明细") or "[]")
    except json.JSONDecodeError:
        items = []
    if items: return items
    # 兼容旧版任务清单：ASIN和掉量起点以相同排序写入。
    return [{"ASIN": asin, "掉量起点": start} for asin, start in zip(
        (task.get("关联我方ASIN") or "").split("；"), (task.get("掉量起点") or "").split("；"))]

def main():
    ap = argparse.ArgumentParser(description="模块B竞对异常卖家精灵MCP原数据拉取")
    ap.add_argument("--tasks", default=str(ROOT / "03_原数据/模块B_竞对异常卖家精灵调用任务清单.csv"))
    ap.add_argument("--coupon-tool", default="Sellersprite-mcp.asin_coupon_trend")
    ap.add_argument("--keepa-tool", default="Sellersprite-mcp.keepa_info")
    ap.add_argument("--output", default=str(ROOT / "03_原数据/模块B_竞对价格促销日快照.csv"))
    ap.add_argument("--keepa-output", default=str(ROOT / "03_原数据/模块B_竞对Keepa趋势原始数据.jsonl"))
    ap.add_argument("--failure-output", default=str(ROOT / "03_原数据/模块B_竞对MCP拉取失败清单.csv"))
    ap.add_argument("--timeout", type=int, default=90)
    ap.add_argument("--pause", type=float, default=0.2, help="每个竞对完成后的等待秒数")
    args = ap.parse_args()

    snapshot_rows, keepa_rows, failures = [], [], []
    for index, task in enumerate(read_csv(args.tasks), start=1):
        comp, market = task["竞对ASIN"], task.get("市场") or "US"
        try:
            coupons = call_mcp(args.coupon_tool, {"marketplace": market, "asin": comp}, args.timeout)
            keepa = call_mcp(args.keepa_tool, {
                "marketplace": market, "asin": comp,
                "startTimestamp": int(task["keepa_startTimestamp"]),
                "endTimestamp": int(task["keepa_endTimestamp"]), "dailyLatest": False,
            }, args.timeout)
        except (OSError, subprocess.TimeoutExpired, RuntimeError, KeyError, ValueError) as exc:
            failures.append({"竞对ASIN": comp, "市场": market, "错误": str(exc), "任务序号": index})
            continue

        keepa_rows.append({"竞对ASIN": comp, "市场": market, "任务": task, "keepa_info原始返回": keepa})
        keepa_data = keepa.get("data", keepa) if isinstance(keepa, dict) else {}
        coupon_by_day = {}
        for item in coupons if isinstance(coupons, list) else []:
            try: coupon_by_day[parse_day(item.get("date"))] = item
            except (TypeError, ValueError): pass

        for item in detail_items(task):
            try:
                own_asin, start = item["ASIN"], date.fromisoformat(item["掉量起点"])
            except (KeyError, ValueError):
                continue
            window_start, window_end = start - timedelta(days=14), start + timedelta(days=7)
            price, _ = trend_by_day(keepa_data.get("price"), window_start, window_end)
            buybox, _ = trend_by_day(keepa_data.get("buyBox"), window_start, window_end)
            bsr, _ = trend_by_day(keepa_data.get("bsr"), window_start, window_end)
            _, deal_points = trend_by_day(keepa_data.get("dealPrice"), window_start, window_end)
            effective_price = {d: as_number(buybox[d]) if as_number(buybox[d]) is not None else as_number(price[d]) for d in price}
            bd = bd_candidate(effective_price)
            previous_final, previous_coupon = None, 0.0
            for offset in range((window_end - window_start).days + 1):
                day = window_start + timedelta(days=offset)
                coupon = coupon_by_day.get(day, {})
                page_price, coupon_price, final_price = as_number(coupon.get("asinPrice")), as_number(coupon.get("couponPrice")), as_number(coupon.get("finalPrice"))
                coupon_price = coupon_price or 0.0
                drop = ((previous_final - final_price) / previous_final * 100) if previous_final and final_price else 0.0
                new_coupon = coupon_price > 0 and previous_coupon <= 0
                snapshot_rows.append({
                    "数据性质": "真实MCP", "ASIN": own_asin, "掉量起点": start.isoformat(), "日期": day.isoformat(),
                    "竞对ASIN": comp, "竞对页面价格": page_price, "Coupon类型": coupon.get("type", ""), "Coupon金额": coupon_price,
                    "竞对实际价格": final_price, "竞对实际价格降幅": round(drop, 4), "新增Coupon": "是" if new_coupon else "否",
                    "LD候选": "是" if day in deal_points else "否", "LD候选价格": deal_points.get(day, ""),
                    "BD候选": "是" if bd.get(day) else "否", "竞对BuyBox价格": buybox.get(day, ""),
                    "竞对页面价趋势": price.get(day, ""), "竞对BSR": bsr.get(day, ""),
                })
                if final_price is not None: previous_final = final_price
                previous_coupon = coupon_price
        if args.pause > 0: time.sleep(args.pause)

    write_csv(Path(args.output), snapshot_rows, [
        "数据性质", "ASIN", "掉量起点", "日期", "竞对ASIN", "竞对页面价格", "Coupon类型", "Coupon金额", "竞对实际价格", "竞对实际价格降幅", "新增Coupon", "LD候选", "LD候选价格", "BD候选", "竞对BuyBox价格", "竞对页面价趋势", "竞对BSR"
    ])
    keepa_path = Path(args.keepa_output); keepa_path.parent.mkdir(parents=True, exist_ok=True)
    with open(keepa_path, "w", encoding="utf-8") as f:
        for row in keepa_rows: f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    write_csv(Path(args.failure_output), failures, ["竞对ASIN", "市场", "错误", "任务序号"])
    print(f"完成：价格促销日快照 {len(snapshot_rows)} 行；Keepa原始返回 {len(keepa_rows)} 个；失败 {len(failures)} 个。")

if __name__ == "__main__":
    main()
