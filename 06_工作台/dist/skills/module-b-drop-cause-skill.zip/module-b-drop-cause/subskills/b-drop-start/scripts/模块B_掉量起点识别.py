#!/usr/bin/env python3
"""模块B 第二步：从 ASIN 日销量识别掉量起点，不做因素归因。"""
import argparse
import csv
from collections import defaultdict
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = next((p for p in SCRIPT_DIR.parents if (p / "03_原数据").is_dir()), SCRIPT_DIR.parents[3])


def num(v):
    try: return float(v or 0)
    except (TypeError, ValueError): return 0.0


def main():
    ap = argparse.ArgumentParser(description="模块B 掉量起点识别")
    ap.add_argument("--input", required=True, help="模块B ASIN日销量原始数据 CSV")
    ap.add_argument("--output-dir", default=str(PACKAGE_ROOT / "04_分析结果"))
    args = ap.parse_args()
    daily = defaultdict(lambda: defaultdict(float))
    with open(args.input, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            daily[r["ASIN"]][r["日期"]] += num(r["出库销量"])
    result = []
    for asin, dates in sorted(daily.items()):
        series = sorted(dates.items(), key=lambda x: x[0])
        start, baseline = "", ""
        for i in range(14, len(series) - 2):
            avg = sum(v for _, v in series[i - 14:i]) / 14
            three_days = [series[i + j][1] for j in range(3)]
            if avg > 0 and all(v < avg * 0.5 for v in three_days):
                start, baseline = series[i][0], round(avg, 2)
                break
        status = "已识别" if start and len([d for d, _ in series if d >= start]) >= 8 else ("观察期未满" if start else "未识别")
        result.append({"ASIN": asin, "掉量起点": start, "前14天日均销量": baseline, "判定状态": status,
                       "规则": "连续3天低于前14天日均销量的50%"})
    output = Path(args.output_dir) / "模块B_ASIN掉量起点表.csv"
    with open(output, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(result[0]) if result else ["ASIN"]); writer.writeheader(); writer.writerows(result)
    print(f"已输出 {len(result)} 个 ASIN：{output}")


if __name__ == "__main__":
    main()
