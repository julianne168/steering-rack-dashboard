#!/usr/bin/env python3
"""模块B：拉取预警 ASIN 的 SMC 当前状态快照。

范围：模块A预警 ASIN、指定店铺（默认 VC1）、Amazon（platform='AM'）。
关联：sc_smc_listing_goods_head.id = 各子表.head_id。

只拉取并展平原数据，不进行原因归因。复用同目录 .env 的 DB_HOST、
DB_PORT、DB_USER、DB_PASSWORD；数据库固定为 suncent-smc。
"""

from __future__ import annotations

import argparse
import csv
import logging
import os
from datetime import datetime
from pathlib import Path

import pandas as pd
import pymysql

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
LOGGER = logging.getLogger(__name__)
SCRIPT_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = next((p for p in SCRIPT_DIR.parents if (p / "03_原数据").is_dir()), SCRIPT_DIR.parents[3])
SMC_DATABASE = "suncent-smc"
SMC_SCHEMA = chr(96) + SMC_DATABASE + chr(96)


def load_env(path: Path) -> None:
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def env_value(name: str, fallback: str = "") -> str:
    return os.getenv(f"DB_{name}", fallback)


def connect() -> pymysql.connections.Connection:
    load_env(SCRIPT_DIR / ".env")
    password = env_value("PASSWORD")
    if not password:
        raise RuntimeError("未配置 SMC_DB_PASSWORD（或通用 DB_PASSWORD）。")
    return pymysql.connect(
        host=env_value("HOST"),
        port=int(env_value("PORT", "9030")),
        user=env_value("USER"),
        password=password,
        # SMC 与其他数仓共用连接参数，但库名必须切换为 suncent-smc。
        database=SMC_DATABASE,
        charset="utf8mb4",
        autocommit=True,
        connect_timeout=30,
        read_timeout=180,
        write_timeout=180,
    )


def warning_asins(path: Path) -> list[str]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return sorted({r["ASIN"].strip() for r in csv.DictReader(handle) if r.get("ASIN") and r.get("预警标记")})


def batches(items: list[str], size: int = 100):
    for index in range(0, len(items), size):
        yield items[index:index + size]


def query_batch(conn: pymysql.connections.Connection, asins: list[str], shop_code: str) -> pd.DataFrame:
    marks = ",".join(["%s"] * len(asins))
    sql = f"""
WITH goods_head AS (
    SELECT id, platform_goods_id, shop_code, standard_price
    FROM {SMC_SCHEMA}.sc_smc_listing_goods_head
    WHERE platform = 'AM' AND shop_code = %s AND platform_goods_id IN ({marks})
),
front_detail AS (
    SELECT
        head_id,
        MAX(CASE WHEN path = 'list_price.value' AND `key` = 'value' THEN value END) AS grey_lp,
        MAX(CASE WHEN path = 'cost_price.value' AND `key` = 'value' THEN value END) AS cost_price
    FROM {SMC_SCHEMA}.sc_smc_amazon_front_detail_v2
    WHERE path IN (
        'list_price.value', 'cost_price.value'
    ) AND `key` = 'value'
    GROUP BY head_id
),
lp_cache AS (
    SELECT head_id, MAX(interface_price) AS interface_lp
    FROM {SMC_SCHEMA}.sc_smc_listing_lp_cache
    GROUP BY head_id
),
labels AS (
    SELECT
        head_id,
        -- SMC 当前有效标签：购物车异常、有购物车、链接异常、变狗、HighCost、广告受限。
        MAX(CASE WHEN label IN ('HighCost', 'HIGH COST') THEN 1 ELSE 0 END) AS high_cost_tag,
        MAX(CASE WHEN label = '有购物车' THEN 1 ELSE 0 END) AS has_buy_box_tag,
        MAX(CASE WHEN label = '链接异常' THEN 1 ELSE 0 END) AS listing_abnormal_tag,
        MAX(CASE WHEN label = '变狗' THEN 1 ELSE 0 END) AS variation_changed_tag,
        MAX(CASE WHEN label = '广告受限' THEN 1 ELSE 0 END) AS ad_restricted_tag,
        MAX(CASE WHEN label = '购物车异常' THEN 1 ELSE 0 END) AS buy_box_abnormal_tag,
        GROUP_CONCAT(DISTINCT label ORDER BY label SEPARATOR '；') AS all_labels
    FROM {SMC_SCHEMA}.sc_smc_listing_label
    GROUP BY head_id
)
SELECT
    gh.platform_goods_id AS asin, gh.shop_code AS shop_code, gh.id AS head_id,
    gh.standard_price AS current_sale, fd.cost_price, lp.interface_lp, fd.grey_lp,
    COALESCE(lb.high_cost_tag, 0) AS high_cost_tag,
    COALESCE(lb.has_buy_box_tag, 0) AS has_buy_box_tag,
    COALESCE(lb.listing_abnormal_tag, 0) AS listing_abnormal_tag,
    COALESCE(lb.variation_changed_tag, 0) AS variation_changed_tag,
    COALESCE(lb.ad_restricted_tag, 0) AS ad_restricted_tag,
    COALESCE(lb.buy_box_abnormal_tag, 0) AS buy_box_abnormal_tag,
    lb.all_labels
FROM goods_head gh
LEFT JOIN front_detail fd ON gh.id = fd.head_id
LEFT JOIN lp_cache lp ON gh.id = lp.head_id
LEFT JOIN labels lb ON gh.id = lb.head_id
ORDER BY asin, head_id
"""
    return pd.read_sql_query(sql, conn, params=[shop_code, *asins])


def main() -> None:
    parser = argparse.ArgumentParser(description="模块B SMC ASIN状态原数据拉取")
    parser.add_argument("--shop-code", default="VC1")
    parser.add_argument("--warning-file")
    parser.add_argument("--output")
    args = parser.parse_args()
    warning_file = Path(args.warning_file) if args.warning_file else PACKAGE_ROOT / "04_分析结果" / "模块A_ASIN周环比监控表_2026-W35_vs_2026-W34.csv"
    asins = warning_asins(warning_file)
    if not asins:
        raise RuntimeError(f"未从预警文件读取到 ASIN：{warning_file}")
    with connect() as conn:
        data = pd.concat([query_batch(conn, batch, args.shop_code) for batch in batches(asins)], ignore_index=True)
    data.insert(0, "快照拉取时间", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    data = data.rename(columns={
        "asin": "ASIN", "shop_code": "店铺", "current_sale": "当前售价",
        "cost_price": "Cost Price", "interface_lp": "界面LP", "grey_lp": "灰色LP",
        "high_cost_tag": "HighCost标签", "has_buy_box_tag": "有购物车标签",
        "listing_abnormal_tag": "链接异常标签",
        "variation_changed_tag": "变狗标签", "ad_restricted_tag": "广告受限标签",
        "buy_box_abnormal_tag": "购物车异常标签", "all_labels": "全部标签",
    })
    output = Path(args.output) if args.output else PACKAGE_ROOT / "03_原数据" / f"模块B_SMC_ASIN当前状态快照_{datetime.now():%Y-%m-%d}.csv"
    output.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(output, index=False, encoding="utf-8-sig")
    LOGGER.info("已导出 %s 行、%s 个 ASIN：%s", len(data), data["ASIN"].nunique(), output)


if __name__ == "__main__":
    main()
