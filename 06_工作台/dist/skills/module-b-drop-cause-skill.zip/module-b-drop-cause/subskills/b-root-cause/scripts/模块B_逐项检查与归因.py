#!/usr/bin/env python3
"""模块B：按掉量起点对齐各异常事件，输出下滑原因归因表。

输入均为真实原数据 CSV；缺少某一来源时保留为“数据不足”，不会把缺数误判为正常。
竞对数据仅接受真实的每日快照；带“数据性质=模拟”的行会被忽略。
优先级：链接异常 > 购物车丢失 > 库存异常 > 涨价 > 广告受限 > 竞对变化。
"""
import argparse
import csv
from datetime import date, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = next((p for p in SCRIPT_DIR.parents if (p / "04_分析结果").is_dir()), SCRIPT_DIR.parents[3])
PRIORITY = ["链接异常", "购物车丢失", "库存异常", "涨价", "广告受限", "竞对变化"]

def read_csv(path):
    if not path or not Path(path).is_file(): return []
    with open(path, encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))
def f(v):
    try: return float(str(v).replace("%","").replace(",","") or 0)
    except ValueError: return 0
def b(v): return str(v).strip().lower() in ("1","true","是","yes")
def aligned(event, start):
    if not event or not start: return "未知"
    try: return "是" if abs((date.fromisoformat(event[:10])-date.fromisoformat(start[:10])).days)<=2 else "否"
    except ValueError: return "未知"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--drop", default=str(ROOT/"04_分析结果/模块B_ASIN掉量起点表.csv"))
    ap.add_argument("--smc", help="模块B_SMC_ASIN当前状态快照 CSV")
    ap.add_argument("--inventory", help="库存日快照 CSV（需含 ASIN/日期/THIRD_PARTY可售库存）")
    ap.add_argument("--competitor", help="竞对日快照 CSV（需含 ASIN/日期/竞对价格降幅/新增促销）")
    ap.add_argument("--ads", help="广告日数据 CSV（需含 ASIN/日期/曝光/广告花费/广告受限）")
    ap.add_argument("--output", default=str(ROOT/"04_分析结果/模块B_下滑原因归因表.csv"))
    a=ap.parse_args()
    drops=[r for r in read_csv(a.drop) if r.get("判定状态") == "已识别" and r.get("掉量起点")]
    smc={r.get("ASIN"):r for r in read_csv(a.smc)}
    inventories=read_csv(a.inventory)
    competitors=[r for r in read_csv(a.competitor) if r.get("数据性质") != "模拟"]
    inventory_asins={r.get("ASIN") for r in inventories if r.get("ASIN")}
    competitor_asins={r.get("ASIN") for r in competitors if r.get("ASIN")}
    ads=read_csv(a.ads)
    rows=[]
    for d in drops:
        asin,start=d["ASIN"],d["掉量起点"]; events=[]
        start_day = date.fromisoformat(start)
        window_start, window_end = start_day - timedelta(days=14), start_day + timedelta(days=7)
        s=smc.get(asin)
        if s:
            if b(s.get("链接异常标签")) or b(s.get("变狗标签")): events.append(("链接异常",s.get("快照拉取时间",""),"SMC标签：链接异常/变狗"))
            if not b(s.get("有购物车标签")) or b(s.get("购物车异常标签")): events.append(("购物车丢失",s.get("快照拉取时间",""),"SMC标签：无购物车或购物车异常"))
            if b(s.get("广告受限标签")): events.append(("广告受限",s.get("快照拉取时间",""),"SMC标签：广告受限"))
        for r in inventories:
            if r.get("ASIN")==asin and f(r.get("THIRD_PARTY可售库存"))<=2: events.append(("库存异常",r.get("日期",""),f"THIRD_PARTY可售库存={r.get('THIRD_PARTY可售库存')}"))
        for r in competitors:
            if r.get("ASIN") != asin:
                continue
            try:
                event_day = date.fromisoformat((r.get("日期") or "")[:10])
            except ValueError:
                continue
            if not window_start <= event_day <= window_end:
                continue
            price_drop = max(f(r.get("竞对价格降幅")), f(r.get("竞对实际价格降幅")))
            promotion = b(r.get("新增促销")) or b(r.get("新增Coupon")) or b(r.get("LD候选")) or b(r.get("BD候选"))
            if price_drop >= 5 or promotion:
                detail=[]
                if price_drop >= 5: detail.append(f"竞对价格降幅={price_drop:.1f}%")
                if b(r.get("新增Coupon")): detail.append("新增Coupon")
                if b(r.get("LD候选")): detail.append("LD候选")
                if b(r.get("BD候选")): detail.append("BD候选")
                if b(r.get("新增促销")) and not detail: detail.append("新增促销")
                events.append(("竞对变化", r.get("日期", ""), "；".join(detail)))
        for r in ads:
            if r.get("ASIN")==asin and (b(r.get("广告受限")) or f(r.get("曝光环比"))<=-50 or f(r.get("广告花费环比"))<=-50): events.append(("广告受限",r.get("日期",""),"广告受限或曝光/花费骤降≥50%"))
        if events:
            selected=sorted(events,key=lambda x: PRIORITY.index(x[0]))[0]
        else:
            missing=[]
            if asin not in smc: missing.append("SMC状态")
            if asin not in inventory_asins: missing.append("库存日快照")
            if asin not in competitor_asins: missing.append("竞对价格快照")
            if missing:
                selected=("原始数据缺失","",f"缺少{'、'.join(missing)}")
            else:
                selected=("未发现异常信号","","SMC、库存与竞对数据齐全，未命中当前归因规则")
        factor,event,evidence=selected; match=aligned(event,start)
        grade="强" if match=="是" and len(events)==1 else ("中" if match=="是" else ("弱" if events else "弱"))
        category="直接原因" if factor in PRIORITY[:5] else ("外部因素" if factor=="竞对变化" else "观察项")
        action={"链接异常":"检查链接状态/变体并修复","购物车丢失":"排查Buy Box资格、价格与配送","库存异常":"补货并核对各仓可售库存","涨价":"复核LP及价格调整","广告受限":"检查活动状态、日志、预算和竞价","竞对变化":"复核竞品促销，不盲目加价","原始数据缺失":"补拉缺失数据后复核","未发现异常信号":"持续观察销量、流量与转化变化"}[factor]
        rows.append({"ASIN":asin,"掉量起点":start,"异常因素":factor,"事件时间点":event,"是否对齐":match,"核心证据":evidence,"证据等级":grade,"原因分类":category,"建议动作":action})
    out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True)
    fields=["ASIN","掉量起点","异常因素","事件时间点","是否对齐","核心证据","证据等级","原因分类","建议动作"]
    with open(out,"w",encoding="utf-8-sig",newline="") as h: w=csv.DictWriter(h,fieldnames=fields); w.writeheader(); w.writerows(rows)
    print(f"已输出 {len(rows)} 行：{out}")
if __name__=="__main__": main()
