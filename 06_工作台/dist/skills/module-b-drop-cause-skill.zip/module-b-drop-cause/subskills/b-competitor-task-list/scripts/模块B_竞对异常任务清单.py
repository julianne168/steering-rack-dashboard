#!/usr/bin/env python3
"""模块B：生成竞对异常的卖家精灵调用任务清单，不调用任何外部接口。

范围仅限“已识别”掉量起点的我方 ASIN。通过日销量原数据的 SKU 与
竞对映射表的“商品编码”关联；对竞对 ASIN 去重后输出一次调用任务。

后续真实拉取时：
1. asin_coupon_trend：页面价、Coupon、实际到手价；
2. keepa_info：dealPrice（LD 候选）、buyBox/price（BD 候选）、BSR。
每个我方 ASIN 的分析窗口固定为掉量起点前14天至后7天；keepa_info
必须设置 dailyLatest=false，以保留日内短时价格点。
"""
import argparse
import csv
import json
from collections import defaultdict
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = next((p for p in SCRIPT_DIR.parents if (p / "03_原数据").is_dir()), SCRIPT_DIR.parents[3])
COMPETITOR_COLUMNS = ("竞对ASIN-1", "竞对ASIN-2", "竞对ASIN-3", "竞对ASIN-4", "竞对ASIN-5",
                      "竞对ASIN-6", "竞对ASIN-7", "竞对ASIN-8", "竞对ASIN-9", "竞对ASIN-10")

def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def iso_millis(day, end=False):
    moment = datetime.combine(day, time.max if end else time.min, tzinfo=timezone.utc)
    return int(moment.timestamp() * 1000)

def valid_asin(value):
    value = (value or "").strip().upper()
    return len(value) == 10 and value.startswith("B0") and value.isalnum()

def main():
    ap = argparse.ArgumentParser(description="生成模块B竞对异常的卖家精灵调用任务清单（不拉取数据）")
    ap.add_argument("--drop", default=str(ROOT / "04_分析结果/模块B_ASIN掉量起点表.csv"))
    ap.add_argument("--sales", default=str(ROOT / "03_原数据/模块B_ASIN日销量原始数据_2026-08-07_至_2026-09-03.csv"))
    ap.add_argument("--mapping", required=True,
                    help="竞对映射表导出的CSV；需含 商品编码、竞对ASIN-1 至 竞对ASIN-10")
    ap.add_argument("--output", default=str(ROOT / "03_原数据/模块B_竞对异常卖家精灵调用任务清单.csv"))
    ap.add_argument("--unmapped-output", default=str(ROOT / "03_原数据/模块B_竞对映射缺失ASIN清单.csv"))
    args = ap.parse_args()

    drops = [r for r in read_csv(args.drop) if r.get("判定状态") == "已识别" and r.get("掉量起点")]
    drop_asins = {r["ASIN"].strip().upper(): r["掉量起点"] for r in drops}
    asin_skus = defaultdict(set)
    for row in read_csv(args.sales):
        asin, sku = (row.get("ASIN") or "").strip().upper(), (row.get("SKU") or "").strip()
        if asin in drop_asins and sku:
            asin_skus[asin].add(sku)

    mapping = {}
    for row in read_csv(args.mapping):
        sku = (row.get("商品编码") or "").strip()
        if not sku:
            continue
        mapping[sku] = sorted({(row.get(col) or "").strip().upper() for col in COMPETITOR_COLUMNS if valid_asin(row.get(col))})

    tasks, unmapped = {}, []
    for asin, start_text in sorted(drop_asins.items()):
        skus = sorted(asin_skus.get(asin, set()))
        competitors = sorted({comp for sku in skus for comp in mapping.get(sku, [])})
        if not competitors:
            unmapped.append({"ASIN": asin, "掉量起点": start_text, "SKU": "；".join(skus), "原因": "未在竞对映射表找到商品编码或有效竞对ASIN"})
            continue
        start = date.fromisoformat(start_text)
        window_start, window_end = start - timedelta(days=14), start + timedelta(days=7)
        for competitor in competitors:
            task = tasks.setdefault(competitor, {
                "竞对ASIN": competitor, "市场": "US", "asin_coupon_trend": "是", "keepa_info": "是",
                "keepa_dailyLatest": "false", "最早窗口开始": window_start, "最晚窗口结束": window_end,
                "关联我方ASIN数": 0, "关联我方ASIN": [], "掉量起点": [], "关联明细": []
            })
            task["最早窗口开始"] = min(task["最早窗口开始"], window_start)
            task["最晚窗口结束"] = max(task["最晚窗口结束"], window_end)
            task["关联我方ASIN"].append(asin)
            task["掉量起点"].append(start_text)
            task["关联明细"].append({"ASIN": asin, "掉量起点": start_text, "SKU": skus})

    output_rows = []
    for task in tasks.values():
        task["关联我方ASIN"] = "；".join(sorted(set(task["关联我方ASIN"])))
        task["掉量起点"] = "；".join(sorted(set(task["掉量起点"])))
        task["关联我方ASIN数"] = len(task["关联我方ASIN"].split("；"))
        task["关联明细"] = json.dumps(task["关联明细"], ensure_ascii=False)
        task["最早窗口开始"] = task["最早窗口开始"].isoformat()
        task["最晚窗口结束"] = task["最晚窗口结束"].isoformat()
        task["keepa_startTimestamp"] = iso_millis(date.fromisoformat(task["最早窗口开始"]))
        task["keepa_endTimestamp"] = iso_millis(date.fromisoformat(task["最晚窗口结束"]), end=True)
        output_rows.append(task)

    fields = ["竞对ASIN", "市场", "asin_coupon_trend", "keepa_info", "keepa_dailyLatest", "最早窗口开始", "最晚窗口结束", "keepa_startTimestamp", "keepa_endTimestamp", "关联我方ASIN数", "关联我方ASIN", "掉量起点", "关联明细"]
    for path, rows, cols in ((Path(args.output), output_rows, fields), (Path(args.unmapped_output), unmapped, ["ASIN", "掉量起点", "SKU", "原因"])):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=cols); writer.writeheader(); writer.writerows(rows)
    print(f"已生成 {len(output_rows)} 个去重竞对的调用任务；{len(unmapped)} 个掉量ASIN缺少竞对映射。未调用卖家精灵。")

if __name__ == "__main__":
    main()
