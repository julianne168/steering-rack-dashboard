#!/usr/bin/env python3
"""模块B质检：确认归因表字段完整、掉量起点存在、强证据事件已对齐。"""
import argparse,csv,sys
from pathlib import Path
SCRIPT_DIR=Path(__file__).resolve().parent
ROOT=next((p for p in SCRIPT_DIR.parents if (p/"04_分析结果").is_dir()),SCRIPT_DIR.parents[3])
ap=argparse.ArgumentParser(); ap.add_argument("--input",default=str(ROOT/"04_分析结果/模块B_下滑原因归因表.csv")); a=ap.parse_args()
with open(a.input,encoding="utf-8-sig",newline="") as f: rows=list(csv.DictReader(f))
required={"ASIN","掉量起点","异常因素","事件时间点","是否对齐","核心证据","证据等级","原因分类","建议动作"}
missing=required-set(rows[0]) if rows else required
bad=[r["ASIN"] for r in rows if r["证据等级"]=="强" and r["是否对齐"]!="是"]
print(f"归因记录={len(rows)}；缺失字段={','.join(sorted(missing)) or '无'}；强证据未对齐={len(bad)}")
sys.exit(1 if missing or bad else 0)
