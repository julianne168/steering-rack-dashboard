#!/usr/bin/env python3
"""模块B 第一步：拉取模块A预警 ASIN 的 Finance 日粒度销量原数据。

只下载数据，不进行掉量或原因判断。
口径：Finance 损益明细、VC1、转向器、模块A预警 ASIN、出库销量/销售额。
"""
import argparse
import csv
import json
import subprocess
from datetime import date, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = next((p for p in SCRIPT_DIR.parents if (p / "03_原数据").is_dir()), SCRIPT_DIR.parents[3])
TOOL = "bi-getdata-finance.query_smartbi_data"


def parse(text):
    start, end = text.find("{"), text.rfind("}")
    return json.loads(text[start:end + 1] if start >= 0 else text)


def query(args):
    result = subprocess.run(["mcporter", "call", TOOL, "--args", json.dumps(args, ensure_ascii=False)],
                            capture_output=True, text=True, encoding="utf-8", timeout=180)
    if result.returncode:
        raise RuntimeError(result.stderr[-500:])
    payload = parse(result.stdout)
    return payload.get("data") or []


def main():
    ap = argparse.ArgumentParser(description="模块B ASIN日销量原数据拉取")
    ap.add_argument("--start", default=(date.today() - timedelta(days=28)).isoformat())
    ap.add_argument("--end", default=(date.today() - timedelta(days=1)).isoformat())
    ap.add_argument("--warning-file", help="模块A最终预警主表 CSV")
    ap.add_argument("--output-dir", default=str(PACKAGE_ROOT / "03_原数据"))
    args = ap.parse_args()
    warning = Path(args.warning_file) if args.warning_file else PACKAGE_ROOT / "04_分析结果" / "模块A_ASIN周环比监控表_2026-W35_vs_2026-W34.csv"
    with open(warning, encoding="utf-8-sig", newline="") as f:
        asins = sorted({r["ASIN"] for r in csv.DictReader(f) if r.get("预警标记")})

    rows = []
    for i in range(0, len(asins), 50):
        batch = asins[i:i + 50]
        data = query({"dimensions": ["period_id_d", "platform_sale_code", "sku"],
                      "measures": ["sales_qty_m", "sales_amount_m"],
                      "filters": [{"name": "shop_code2", "operation": "EQUALS", "values": ["VC1"]},
                                  {"name": "operation_classification2", "operation": "EQUALS", "values": ["转向器"]},
                                  {"name": "platform_sale_code", "operation": "IN", "values": batch},
                                  {"name": "period_id_d", "operation": "GREATER_EQUALS", "values": [args.start]},
                                  {"name": "period_id_d", "operation": "LESS_EQUALS", "values": [args.end]}], "limit": -1})
        rows.extend(data)
        print(f"已拉取 {min(i + 50, len(asins))}/{len(asins)} 个预警 ASIN", flush=True)

    output = Path(args.output_dir) / f"模块B_ASIN日销量原始数据_{args.start}_至_{args.end}.csv"
    fields = ["日期", "ASIN", "SKU", "出库销量", "出库销售额"]
    with open(output, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader()
        for r in rows:
            writer.writerow({"日期": r.get("period_id_d", ""), "ASIN": r.get("platform_sale_code", ""), "SKU": r.get("sku", ""),
                             "出库销量": r.get("sales_qty_m", 0), "出库销售额": r.get("sales_amount_m", 0)})
    print(f"已保存 {len(rows)} 条：{output}")


if __name__ == "__main__":
    main()
