---
name: xbm-steering-module-b-drop-cause
description: 识别预警 ASIN 的掉量起点，并按链接、购物车、库存、涨价、广告与竞对因素形成归因。 适用于转向器广告复盘的模块 B 全流程执行。
---

# 模块 B：掉量原因归因

## 目的

识别预警 ASIN 的掉量起点，并按链接、购物车、库存、涨价、广告与竞对因素形成归因。

本主技能包含本模块全部脚本子技能及其附属脚本，可作为独立模块整体使用。

## 使用顺序

1. [模块 B ASIN 日销量拉取](subskills/b-daily-sales-pull/SKILL.md)：拉取掉量起点识别所需 ASIN 日粒度销量。
2. [模块 B SMC 状态拉取](subskills/b-smc-status-pull/SKILL.md)：拉取当前售价、LP、购物车、变狗、HighCost 和广告受限等 SMC 状态。
3. [模块 B THIRD_PARTY 库存拉取](subskills/b-third-party-inventory-pull/SKILL.md)：拉取商品编码的 THIRD_PARTY 各仓可售库存并用于断货判断。
4. [模块 B 竞对异常任务清单](subskills/b-competitor-task-list/SKILL.md)：仅为掉量 ASIN 的关联竞对生成 21 天页面价格与优惠趋势拉取任务。
5. [模块 B 竞对异常原数据拉取](subskills/b-competitor-data-pull/SKILL.md)：通过卖家精灵 MCP 获取竞对历史页面价、优惠、到手价、LD/BD 与 BSR 验证数据。
6. [模块 B 掉量起点识别](subskills/b-drop-start/SKILL.md)：识别连续 3 天低于此前 14 天日均销量 50% 的首次掉量日期。
7. [模块 B 逐项检查与归因](subskills/b-root-cause/SKILL.md)：按链接、购物车、库存、涨价、广告、竞对优先级形成原因、证据和建议。
8. [模块 B 质检](subskills/b-quality-check/SKILL.md)：检查模块 B 数据覆盖、时间窗和归因输出完整性。

## 输出

完成后使用模块末一步对应的 `04_分析结果/` 文件作为本模块交付；若主技能需要刷新工作台，再运行“工作台结果同步”子技能。

## 使用约束

- 开始前确定一个项目根目录；对本模块每个子技能使用同一个 `--workspace-root <项目根目录>`，以保证原数据和结果在同一工作区衔接。
- 仅使用资料包 `02_脚本/当前主力/` 的对应脚本，不混用历史参考脚本。
- 拉取前确认 `.env`、数据源权限和上游结果可用；禁止把凭据写入代码或结果。
- 本模块只分析和生成建议。广告、否词、价格或 GitHub 的实际变更必须获得单独授权。
