#!/usr/bin/env python3
"""模块E：用ASIN适配表校验模块D待否词，防止误否正确车型或年份。"""
import re
from pathlib import Path
import pandas as pd
HERE=Path(__file__).resolve().parent; ROOT=next(p for p in HERE.parents if (p/'03_原数据').is_dir())
def norm(x): return re.sub(r'\s+',' ',str(x).lower().replace('-',' ')).strip()
def sid(x):
 s=str(x).strip(); return s[:-2] if s.endswith('.0') else s
def main():
 d=pd.read_csv(ROOT/'04_分析结果/模块D_否词清单.csv',encoding='utf-8-sig',dtype=str).fillna('')
 fit=pd.read_csv(ROOT/'03_原数据/模块C_转向器ASIN适配原始数据.csv',encoding='utf-8-sig',dtype=str).fillna('')
 fit['ASIN']=fit['ASIN'].map(sid)
 for c in ['品牌','车型','年份']:fit[c]=fit[c].map(norm)
 profile={a:list(g[['品牌','车型','年份']].drop_duplicates().itertuples(index=False,name=None)) for a,g in fit.groupby('ASIN')}
 act=pd.read_excel(ROOT/'03_原数据/模块A_领星ASIN广告指标周环比表.xlsx',sheet_name='ASIN对应活动清单',usecols=['年周','活动ID','ASIN'])
 week=sorted(act['年周'].dropna().astype(str).unique())[-1];act=act[act['年周'].astype(str)==week].copy();act['活动ID']=act['活动ID'].map(sid);act['ASIN']=act['ASIN'].map(sid)
 campaign=act.groupby('活动ID')['ASIN'].apply(lambda x:set(x)).to_dict(); rows=[]
 for r in d.itertuples(index=False):
  asin,term=sid(r.ASIN),norm(r.搜索词); rec=profile.get(asin,[]); years=set(re.findall(r'(?<!\d)(?:19|20)\d{2}(?!\d)',term))
  matches=[(b,m,y) for b,m,y in rec if b in term and m in term]
  correct=any(not years or not y or y in years for _,_,y in matches)
  cid=sid(r.活动ID); others=[x for x in campaign.get(cid,set()) if x!=asin]
  other_fit=any(any(b in term and m in term and (not years or not y or y in years) for b,m,y in profile.get(x,[])) for x in others)
  if not rec: status,decision,reason,action='待人工确认','不可自动否定','适配表无该ASIN数据','补齐适配后人工复核'
  elif correct: status,decision,reason,action='正确车型/年份','禁止否定','搜索词命中该ASIN适配品牌/车型/年份','从否词清单移除'
  elif other_fit: status,decision,reason,action='混合活动其他ASIN适配','可否定（仅广告组）','该ASIN不适配，但同活动其他ASIN适配','仅对该ASIN广告组否定（L3）'
  else: status,decision,reason,action='适配外','可否定','未命中该ASIN适配范围','在活动级添加否词（L2）'
  rows.append({'待否词':r.搜索词,'广告活动':r.广告活动,'活动ID':cid,'ASIN':asin,'原判定类型':r.判定类型,'原应用层级':r.应用层级,'适配状态':status,'可否决':decision,'原因':reason,'处理动作':action,'确认状态':'待运营确认'})
 out=ROOT/'04_分析结果/模块E_否词校验表.csv';pd.DataFrame(rows).to_csv(out,index=False,encoding='utf-8-sig');print(f'待校验={len(rows)}；输出={out}')
if __name__=='__main__':main()
