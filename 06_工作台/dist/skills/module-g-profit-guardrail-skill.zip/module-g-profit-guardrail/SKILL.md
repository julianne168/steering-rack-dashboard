---
name: xbm-steering-module-g-profit-guardrail
description: 计算 ASIN 平衡 ACOS 和目标 ACOS，为所有增投建议提供利润护栏。 适用于转向器广告复盘的模块 G 全流程执行。
---

# 模块 G：盈亏平衡 ACOS

## 目的

计算 ASIN 平衡 ACOS 和目标 ACOS，为所有增投建议提供利润护栏。

本主技能包含本模块全部脚本子技能及其附属脚本，可作为独立模块整体使用。

## 使用顺序

1. [模块 G 损益成本原数据拉取](subskills/g-profit-cost-pull/SKILL.md)：拉取 ASIN 售价、销量、成本、费用与广告花费。
2. [模块 G ASIN 盈亏平衡 ACOS 分析](subskills/g-break-even-acos/SKILL.md)：计算平衡 ACOS、目标 ACOS 和可增投/需优化状态。
3. [模块 G 结果质检](subskills/g-quality-check/SKILL.md)：检查盈亏平衡 ACOS 结果的字段、计算和状态完整性。

## 输出

完成后使用模块末一步对应的 `04_分析结果/` 文件作为本模块交付；若主技能需要刷新工作台，再运行“工作台结果同步”子技能。

## 使用约束

- 开始前确定一个项目根目录；对本模块每个子技能使用同一个 `--workspace-root <项目根目录>`，以保证原数据和结果在同一工作区衔接。
- 仅使用资料包 `02_脚本/当前主力/` 的对应脚本，不混用历史参考脚本。
- 拉取前确认 `.env`、数据源权限和上游结果可用；禁止把凭据写入代码或结果。
- 本模块只分析和生成建议。广告、否词、价格或 GitHub 的实际变更必须获得单独授权。
