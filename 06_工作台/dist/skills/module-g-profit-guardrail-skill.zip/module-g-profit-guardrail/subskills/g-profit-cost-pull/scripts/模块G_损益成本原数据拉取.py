#!/usr/bin/env python3
"""模块G：从 BI 损益明细拉取ASIN成本及广告费原数据，不做盈亏判断。

口径：shop_code2=VC1、operation_classification2=转向器、平台销售编码 B0 开头。
默认取最近一个完整自然月；2026-09-08 运行时即为 2026-08。
"""
import argparse
import csv
import json
import os
from datetime import date
from pathlib import Path

import requests

MCP_URL = "https://higress.suncentgroup.com/mcp-servers/bi-getdata-finance"
MCP_TOOL = "query_smartbi_data"
DIMENSIONS = ["period_id_d_Month2", "platform_sale_code", "sku"]
MEASURES = [
    "sales_qty_m", "sales_amount_m", "sales_purchase_amount_real_m", "sales_first_leg_amount_real_m",
    "commission_m", "tax_fee_m", "storage_fee_m", "courier_fee_m",
    "ad_spend_sp_m", "ad_spend_sd_m", "ad_spend_sb_m",
    "材料单价_实际", "头程单价_实际",
]
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = next((p for p in SCRIPT_DIR.parents if (p / "03_原数据").is_dir()), SCRIPT_DIR.parents[3])

def previous_month(today=None):
    today = today or date.today()
    year, month = today.year, today.month - 1
    if month == 0: year, month = year - 1, 12
    return f"{year}-{month:02d}"

def parse_json(text):
    try: return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end < start: raise RuntimeError(f"BI 返回无法解析：{text[:500]}")
        return json.loads(text[start:end + 1])

def parse_mcp_response(response):
    """解析服务器的 application/json 或 text/event-stream 响应。"""
    response.raise_for_status()
    text = response.content.decode("utf-8")
    if "text/event-stream" in response.headers.get("content-type", ""):
        messages = [line[5:].strip() for line in text.splitlines() if line.startswith("data:")]
        if not messages: raise RuntimeError("MCP 事件流中没有 data 消息")
        payload = json.loads(messages[-1])
    else:
        payload = json.loads(text)
    if payload.get("error"): raise RuntimeError(f"MCP 返回错误：{payload['error']}")
    return payload.get("result", {})

def mcp_query(request):
    token = os.environ.get("SUNCENT_BI_TOKEN")
    if not token:
        raise RuntimeError("未检测到 SUNCENT_BI_TOKEN。请在本机环境变量配置BI MCP令牌后重试。")
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
    session = requests.Session()
    init = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-03-26", "capabilities": {}, "clientInfo": {"name": "module-g-finance", "version": "1.0"}}}
    initial = session.post(MCP_URL, headers=headers, json=init, timeout=30)
    parse_mcp_response(initial)
    if initial.headers.get("mcp-session-id"): headers["mcp-session-id"] = initial.headers["mcp-session-id"]
    session.post(MCP_URL, headers=headers, json={"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}, timeout=30)
    call = {"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": MCP_TOOL, "arguments": request}}
    result = parse_mcp_response(session.post(MCP_URL, headers=headers, json=call, timeout=180))
    contents = result.get("content", [])
    text_items = [item.get("text", "") for item in contents if item.get("type") == "text"]
    if not text_items: raise RuntimeError("BI MCP 未返回文本数据")
    return parse_json(text_items[-1])

def get(row, field, label):
    return row.get(field, row.get(label, ""))

def main():
    ap = argparse.ArgumentParser(description="模块G损益成本原数据拉取")
    ap.add_argument("--month", default=previous_month(), help="年月，如2026-08；默认最近完整自然月")
    ap.add_argument("--output-dir", default=str(ROOT / "03_原数据"))
    args = ap.parse_args()
    request = {
        "dimensions": DIMENSIONS, "measures": MEASURES,
        "filters": [
            {"name": "shop_code2", "operation": "EQUALS", "values": ["VC1"]},
            {"name": "period_id_d_Month2", "operation": "EQUALS", "values": [args.month]},
            {"name": "operation_classification2", "operation": "EQUALS", "values": ["转向器"]},
            {"name": "platform_sale_code", "operation": "STARTWITH", "values": ["B0"]},
        ], "limit": -1,
    }
    payload = mcp_query(request)
    if payload.get("error"): raise RuntimeError(f"BI 查询返回错误：{payload['error']}")
    data = payload.get("data") or payload.get("result") or []
    if isinstance(data, str): data = parse_json(data).get("data", [])
    if not isinstance(data, list): raise RuntimeError("BI 返回 data 不是明细列表")

    labels = {
        "period_id_d_Month2": "年月", "platform_sale_code": "ASIN", "sku": "SKU",
        "sales_qty_m": "出库销量", "sales_amount_m": "出库销售额", "sales_purchase_amount_real_m": "采购成本-实际",
        "sales_first_leg_amount_real_m": "头程成本-实际", "commission_m": "佣金", "tax_fee_m": "税费",
        "storage_fee_m": "仓储费", "courier_fee_m": "尾程费", "ad_spend_sp_m": "广告花费-SP",
        "ad_spend_sd_m": "广告花费-SD", "ad_spend_sb_m": "广告花费-SB", "材料单价_实际": "材料单价_实际", "头程单价_实际": "头程单价_实际",
    }
    rows = []
    for source in data:
        asin = str(get(source, "platform_sale_code", "平台销售编码")).strip().upper()
        if not asin.startswith("B0"): continue
        rows.append({label: get(source, field, label) for field, label in labels.items()})
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    path = out / f"模块G_损益成本原始数据_{args.month}.csv"
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(labels.values())); writer.writeheader(); writer.writerows(rows)
    print(f"已保存 {len(rows)} 条模块G损益成本原数据：{path}")

if __name__ == "__main__": main()
