#!/usr/bin/env python3
"""模块C：拉取转向器 ASIN 车型适配原数据。

数据来源：dw.dwi_matching_criterion_vio_bi + dw.dw_dim_sku_salesperson_snapshot。
口径严格复用徐业 2026-08-31 SQL：美国、配件事业部、AMAZON、转向器、
当月最新 ASIN→SPU 映射，并按 ASIN 的车型 VIO 降序编号。
"""
import argparse
import logging
import os
from pathlib import Path

import pandas as pd
import pymysql

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
LOGGER=logging.getLogger(__name__)
SCRIPT_DIR=Path(__file__).resolve().parent
ROOT=next((p for p in SCRIPT_DIR.parents if (p/"03_原数据").is_dir()),SCRIPT_DIR.parents[3])

SQL="""
WITH c AS (
    SELECT
        DISTINCT sp.platform_sale_code AS platform_sale_code,
        sp.product_category_code AS product_category_code,
        mc.product_code AS product_code,
        -- 新增：vio_bi中的product_code
        mc.year AS year,
        LOWER(mc.make) AS make,
        LOWER(mc.model) AS model,
        mc.liters,
        mc.vio AS vio
    FROM
        (
            SELECT
                product_code,
                year,
                make,
                model,
                liters,
                vio,
                product_category_code
            FROM
                dw.dwi_matching_criterion_vio_bi
            WHERE
                region = 'United States'
        ) AS mc
        RIGHT JOIN (
            SELECT
                platform_sale_code,
                operators_ch,
                manager,
                product_category_code,
                spu
            FROM
                (
                    SELECT
                        platform_sale_code,
                        operators_ch,
                        manager,
                        product_category_code,
                        spu,
                        ROW_NUMBER() OVER (
                            PARTITION BY
                                platform_sale_code
                            ORDER BY
                                mapping_update_time DESC
                        ) AS ra
                    FROM
                        dw.dw_dim_sku_salesperson_snapshot
                    WHERE
                        platform_sale_code IS NOT NULL
                        AND spu IS NOT NULL
                        AND period_id_m = DATE_FORMAT(CURDATE(), '%Y%m')
                        AND business_division = '配件事业部'
                        AND platform = 'AMAZON'
                        AND operation_classification = '转向器'
                ) AS ranked_data
            WHERE
                ra = 1
        ) AS sp ON mc.product_code = sp.spu
),
agg AS (
    SELECT
        c.platform_sale_code,
        c.product_code,
        -- 新增
        c.year,
        c.make,
        c.model,
        c.liters,
        SUM(c.vio) AS vio_sum
    FROM
        c
    GROUP BY
        c.platform_sale_code,
        c.product_code,
        -- 新增
        c.year,
        c.make,
        c.model,
        c.liters
),
ranked AS (
    SELECT
        agg.platform_sale_code,
        agg.product_code,
        -- 新增
        agg.year,
        agg.make,
        agg.model,
        agg.liters,
        agg.vio_sum,
        ROW_NUMBER() OVER (
            PARTITION BY
                agg.platform_sale_code
            ORDER BY
                agg.vio_sum DESC
        ) AS rn
    FROM
        agg
)
SELECT
    ranked.platform_sale_code,
    ranked.product_code,
    -- 新增输出
    ranked.year,
    ranked.make,
    ranked.model,
    ranked.liters,
    ranked.vio_sum,
    ranked.rn
FROM
    ranked;
"""

def load_env():
    path=SCRIPT_DIR/".env"
    if path.is_file():
        for line in path.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k,v=line.split("=",1); os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))
def main():
    ap=argparse.ArgumentParser(description="模块C适配数据拉取")
    ap.add_argument("--output",default=str(ROOT/"03_原数据/模块C_转向器ASIN适配原始数据.csv"))
    a=ap.parse_args(); load_env()
    password=os.getenv("DB_PASSWORD","")
    if not password: raise RuntimeError("未配置 DB_PASSWORD。")
    db=pymysql.connect(host=os.getenv("DB_HOST"),port=int(os.getenv("DB_PORT","9030")),
        user=os.getenv("DB_USER"),password=password,database=os.getenv("DB_NAME","dw"),
        charset="utf8mb4",connect_timeout=30,read_timeout=180,write_timeout=180)
    try: data=pd.read_sql_query(SQL,db)
    finally: db.close()
    data=data.rename(columns={"platform_sale_code":"ASIN","product_code":"商品编码","year":"年份","make":"品牌","model":"车型","liters":"排量","vio_sum":"VIO汇总","rn":"ASIN内VIO排序"})
    out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True)
    data.to_csv(out,index=False,encoding="utf-8-sig")
    LOGGER.info("已导出 %s 行、%s 个 ASIN：%s",len(data),data["ASIN"].nunique(),out)
if __name__=="__main__": main()
