#!/usr/bin/env python3
"""模块C：活动体检、ASIN适配范围分组与冲突候选。

已用数据：领星活动-ASIN清单、转向器ASIN适配原数据。
未用数据：搜索词/投放词明细。因此本脚本只能输出“适配冲突候选”，
不能将候选直接判定为真实错配流量；真实冲突需补搜索词按ASIN明细验证。
"""
import argparse
from pathlib import Path
import pandas as pd

SCRIPT_DIR=Path(__file__).resolve().parent
ROOT=next((p for p in SCRIPT_DIR.parents if (p/"03_原数据").is_dir()),SCRIPT_DIR.parents[3])
def num(s):
    return pd.to_numeric(s,errors="coerce").fillna(0)
def profiles(fit):
    fit=fit.copy()
    for c in ["品牌","车型","年份","排量"]: fit[c]=fit[c].fillna("").astype(str).str.strip().str.lower()
    fit["车型键"]=fit["品牌"]+"|"+fit["车型"]+"|"+fit["年份"]+"|"+fit["排量"]
    result=[]
    for asin,g in fit.groupby("ASIN"):
        keys=set(g["车型键"])-{"|||"}
        top=g.sort_values("VIO汇总",ascending=False).head(3)
        desc="；".join(f"{x.品牌} {x.车型} {x.年份}" for x in top.itertuples())
        result.append({"ASIN":asin,"商品编码":g["商品编码"].dropna().iloc[0] if g["商品编码"].notna().any() else "",
                       "适配车型数":len(keys),"适配画像Top3":desc,"适配键集":keys})
    return pd.DataFrame(result)
def overlap(a,b):
    if not a or not b:return 0
    return len(a&b)/min(len(a),len(b))*100
def main():
    ap=argparse.ArgumentParser(description="模块C活动体检与适配范围分组")
    ap.add_argument("--activity",default=str(ROOT/"03_原数据/模块A_领星ASIN广告指标周环比表.xlsx"))
    ap.add_argument("--fitment",default=str(ROOT/"03_原数据/模块C_转向器ASIN适配原始数据.csv"))
    ap.add_argument("--output-dir",default=str(ROOT/"04_分析结果"))
    ap.add_argument("--year-week",default=None,help="分析周；默认使用活动明细中的最新年周")
    ap.add_argument("--export-pair-detail",action="store_true",help="按活动导出全部ASIN两两适配明细（文件可能很大）")
    a=ap.parse_args(); out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
    activity=pd.read_excel(a.activity,sheet_name="ASIN对应活动清单")
    fit=pd.read_csv(a.fitment,encoding="utf-8-sig")
    if "年周" not in activity.columns:
        raise ValueError("活动明细缺少“年周”字段，无法确定模块C的统计期间。")
    all_weeks=sorted(activity["年周"].dropna().astype(str).unique())
    selected_week=a.year_week or all_weeks[-1]
    activity=activity[activity["年周"].astype(str)==selected_week].copy()
    if activity.empty:
        raise ValueError(f"找不到年周 {selected_week} 的活动明细；可选：{', '.join(all_weeks)}")
    profile=profiles(fit)
    metrics=["曝光","点击","广告订单","广告销售额","广告花费"]
    for c in metrics: activity[c]=num(activity[c])
    base=activity.groupby(["活动ID","活动名称","广告组合","状态","广告类型","投放方式"],dropna=False).agg(
        ASIN数=("ASIN","nunique"),ASIN列表=("ASIN",lambda x:"；".join(sorted(set(x.astype(str))))),
        曝光=("曝光","sum"),点击=("点击","sum"),广告订单=("广告订单","sum"),广告销售额=("广告销售额","sum"),广告花费=("广告花费","sum")
    ).reset_index()
    base["活动类型判定"]=base["ASIN数"].map(lambda x:"重点检查（ASIN≥15）" if x>=15 else ("多ASIN，按适配范围检查" if x>=2 else "单ASIN"))
    base["ACOS%"]=base.apply(lambda r:r["广告花费"]/r["广告销售额"]*100 if r["广告销售额"] else None,axis=1)
    active_asins=set(activity["ASIN"].dropna().astype(str))
    profile=profile[profile["ASIN"].isin(active_asins)].copy()
    pmap=profile.set_index("ASIN").to_dict("index")
    group_rows=[]; action_rows=[]; conflict_rows=[]
    for _, r in base.iterrows():
        asins=r["ASIN列表"].split("；"); ps=[pmap.get(x) for x in asins]
        missing=[x for x,p in zip(asins,ps) if not p or not p["适配键集"]]
        pairs=[]; candidate_count=0
        for i in range(len(asins)):
            for j in range(i+1,len(asins)):
                score=overlap(ps[i]["适配键集"],ps[j]["适配键集"]) if ps[i] and ps[j] else 0
                pairs.append(score)
                candidate_count += int(score < 80)
                if a.export_pair_detail:
                    conflict_rows.append({"活动ID":r["活动ID"],"活动名称":r["活动名称"],"ASIN_A":asins[i],"ASIN_B":asins[j],
                      "适配重叠率%":round(score,1),"冲突候选": "是" if score<80 else "否",
                      "结论":"待补搜索词/投放词按ASIN明细验证实际错配流量"})
        minimum=min(pairs) if pairs else 100
        conflict_rows.append({"活动ID":r["活动ID"],"活动名称":r["活动名称"],"活动ASIN数":r["ASIN数"],
          "ASIN配对数":len(pairs),"低重叠配对数":candidate_count,
          "低重叠占比%":round(candidate_count/len(pairs)*100,1) if pairs else 0,
          "最低适配重叠率%":round(minimum,1),"判定":"待搜索词验证" if pairs else "单ASIN，不适用",
          "说明":"低重叠仅代表适配范围差异；补齐搜索词/投放词按ASIN明细后，才可确认实际错配流量。"})
        if missing: action="单独低预算跑"
        elif r["ASIN数"]==1: action="保留，按表现继续投放"
        elif minimum>=80: action="可以放一起，统一否词"
        else: action="拆开，按适配范围重建"
        if r["广告花费"]>100 and r["广告订单"]==0: action="暂停或移除"
        action_rows.append({"活动ID":r["活动ID"],"原活动名":r["活动名称"],"ASIN数":r["ASIN数"],"ASIN列表":r["ASIN列表"],
          "最低适配重叠率%":round(minimum,1),"适配空白ASIN":"；".join(missing),"冲突等级":"待搜索词验证" if r["ASIN数"]>=2 else "不适用",
          "处置动作":action,"广告花费":round(r["广告花费"],2),"广告订单":r["广告订单"],"ACOS%":round(r["ACOS%"],2) if pd.notna(r["ACOS%"]) else ""})
    # 适配重叠率达到80%的活跃ASIN归入同一适配范围分组。
    parents={asin:asin for asin in profile["ASIN"]}
    def find(x):
        while parents[x] != x:
            parents[x]=parents[parents[x]]; x=parents[x]
        return x
    def union(a1,b1):
        a1,b1=find(a1),find(b1)
        if a1 != b1: parents[b1]=a1
    active_profiles=list(profile.itertuples())
    for i, p1 in enumerate(active_profiles):
        for p2 in active_profiles[i+1:]:
            if overlap(p1.适配键集,p2.适配键集) >= 80: union(p1.ASIN,p2.ASIN)
    family={}
    for asin in parents: family.setdefault(find(asin),[]).append(asin)
    family_id={asin:f"F{n:03d}" for n, members in enumerate(family.values(),1) for asin in members}
    family_size={asin:len(family[find(asin)]) for asin in parents}
    for p in profile.itertuples():
        group_rows.append({"ASIN":p.ASIN,"商品编码":p.商品编码,"适配make/model/year":p.适配画像Top3,
          "适配车型数":p.适配车型数,"适配范围分组编号":family_id.get(p.ASIN,""),"同组ASIN数":family_size.get(p.ASIN,0),
          "分组说明":"适配范围重叠率≥80%的ASIN放在同一组","建议活动":"单独低预算跑" if not p.适配键集 else "按活动处置清单执行"})
    pd.DataFrame(action_rows).to_csv(out/"模块C_活动处置清单_初版.csv",index=False,encoding="utf-8-sig")
    pd.DataFrame(group_rows).to_csv(out/"模块C_ASIN适配范围分组表_初版.csv",index=False,encoding="utf-8-sig")
    suffix="明细" if a.export_pair_detail else "汇总"
    pd.DataFrame(conflict_rows).to_csv(out/f"模块C_适配冲突候选{suffix}.csv",index=False,encoding="utf-8-sig")
    print(f"统计周={selected_week}；活动={len(base)}；多ASIN={sum(base['ASIN数']>=2)}；适配ASIN={len(profile)}")
if __name__=="__main__": main()
