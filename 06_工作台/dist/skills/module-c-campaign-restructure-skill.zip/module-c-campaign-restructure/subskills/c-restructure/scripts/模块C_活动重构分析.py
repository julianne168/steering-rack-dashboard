#!/usr/bin/env python3
"""模块C：按《多ASIN广告活动重构分析框架V1》输出最终处置与重复活动清单。"""
import argparse
import re
from pathlib import Path
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / "03_原数据").is_dir())
NUM = ["曝光", "点击", "广告花费", "广告订单", "广告销售额"]

def n(x): return pd.to_numeric(x, errors="coerce").fillna(0)
def normal(s): return re.sub(r"\s+", " ", str(s).lower().replace("-", " ")).strip()

def build_fitments(fit):
    """ASIN -> 可用 make/model/year 记录；只用“品牌+车型”同时出现在词中的明确证据。"""
    d = fit.copy()
    for c in ["ASIN", "品牌", "车型", "年份"]: d[c] = d[c].fillna("").astype(str)
    result = {}
    for asin, g in d.groupby("ASIN"):
        rows = []
        for r in g[["品牌", "车型", "年份"]].drop_duplicates().itertuples(index=False):
            make, model, year = map(normal, r)
            if make and model and model not in {"nan", "none"}:
                rows.append((make, model, year))
        result[str(asin)] = rows
    return result

def term_fitment(term, records):
    """返回词是否有明确车型证据，以及是否与该ASIN适配。"""
    text = normal(term)
    years = set(re.findall(r"(?<!\d)(?:19|20)\d{2}(?!\d)", text))
    matched = False
    for make, model, year in records:
        if make in text and model in text:
            matched = True
            if not years or not year or year in years:
                return True, True
    return matched, False

def fitment_keys(records):
    return {f"{make}|{model}|{year}" for make, model, year in records}

def minimum_overlap(asins, fit):
    keys = [fitment_keys(fit.get(asin, [])) for asin in asins]
    scores = []
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            if not keys[i] or not keys[j]:
                scores.append(0.0)
            else:
                scores.append(len(keys[i] & keys[j]) / min(len(keys[i]), len(keys[j])) * 100)
    return min(scores) if scores else 100.0

def week_activity(path):
    d = pd.read_excel(path, sheet_name="ASIN对应活动清单")
    week = sorted(d["年周"].dropna().astype(str).unique())[-1]
    d = d[d["年周"].astype(str).eq(week)].copy()
    for c in NUM: d[c] = n(d[c])
    keys = ["活动ID", "活动名称", "广告组合", "状态", "广告类型", "投放方式"]
    c = d.groupby(keys, dropna=False).agg(ASIN数=("ASIN", "nunique"), ASIN列表=("ASIN", lambda x: "；".join(sorted(set(x.astype(str))))),
        曝光=("曝光", "sum"), 点击=("点击", "sum"), 广告花费=("广告花费", "sum"), 广告订单=("广告订单", "sum"), 广告销售额=("广告销售额", "sum")).reset_index()
    return week, c

def main():
    p = argparse.ArgumentParser(description="模块C最终活动重构分析")
    p.add_argument("--activity", default=str(ROOT / "03_原数据/模块A_领星ASIN广告指标周环比表.xlsx"))
    p.add_argument("--fitment", default=str(ROOT / "03_原数据/模块C_转向器ASIN适配原始数据.csv"))
    p.add_argument("--search-term", default=str(ROOT / "03_原数据/模块C_搜索词报告_近30天.csv"))
    p.add_argument("--breakeven-acos", type=float, default=None, help="盈亏平衡ACOS，如 0.30；未提供时只自动识别高冲突（有花费0单）")
    p.add_argument("--output-dir", default=str(ROOT / "04_分析结果"))
    a = p.parse_args(); out = Path(a.output_dir); out.mkdir(parents=True, exist_ok=True)
    week, campaigns = week_activity(Path(a.activity))
    fit = build_fitments(pd.read_csv(a.fitment, encoding="utf-8-sig"))
    st = pd.read_csv(a.search_term, encoding="utf-8-sig")
    for c in NUM: st[c] = n(st[c])
    st["活动ID"] = st["活动ID"].astype(str); st["ASIN"] = st["ASIN"].astype(str)
    campaign_asins = {str(r["活动ID"]): r["ASIN列表"].split("；") for _, r in campaigns.iterrows()}
    st = st[st["活动ID"].isin(campaign_asins)].copy()
    terms = st.groupby(["活动ID", "活动名称", "ASIN", "搜索词"], dropna=False)[NUM].sum().reset_index()
    evidence = []
    for row in terms.itertuples(index=False):
        cid, current, term = str(row.活动ID), str(row.ASIN), row.搜索词
        active = campaign_asins.get(cid, [])
        source = [asin for asin in active if asin != current and term_fitment(term, fit.get(asin, []))[1]]
        _, current_ok = term_fitment(term, fit.get(current, []))
        if not source or current_ok:
            continue
        spend, orders, sales = float(row.广告花费), float(row.广告订单), float(row.广告销售额)
        acos = spend / sales if sales else None
        if spend > 0 and orders == 0: level = "高"
        elif spend > 0 and a.breakeven_acos is not None and acos is not None and acos > a.breakeven_acos: level = "中"
        else: level = "低"
        evidence.append({"活动ID":cid, "活动名称":row.活动名称, "实际承接ASIN":current, "适配来源ASIN":"；".join(source),
            "搜索词":term, "曝光":row.曝光, "点击":row.点击, "广告花费":spend, "广告订单":orders, "广告销售额":sales,
            "ACOS%":round(acos * 100, 2) if acos is not None else "", "冲突等级":level,
            "判定依据":"适配来源ASIN的车型词实际流量落在不适配ASIN"})
    evidence = pd.DataFrame(evidence)
    high_mid = set() if evidence.empty else set(evidence.loc[evidence["冲突等级"].isin(["高", "中"]), "活动ID"])
    summary = {} if evidence.empty else evidence.groupby("活动ID").agg(高冲突数=("冲突等级", lambda x: (x == "高").sum()),
        中冲突数=("冲突等级", lambda x: (x == "中").sum()), 低冲突数=("冲突等级", lambda x: (x == "低").sum()),
        错配花费=("广告花费", "sum"), 错配订单=("广告订单", "sum")).to_dict("index")
    rows = []
    for _, r in campaigns.iterrows():
        cid, asins = str(r["活动ID"]), r["ASIN列表"].split("；")
        blank = [x for x in asins if not fit.get(x)]
        conf = summary.get(cid, {})
        overlap = minimum_overlap(asins, fit)
        if r["广告花费"] > 100 and r["广告订单"] == 0: action, new = "暂停或移除", "暂停原活动，避免继续产生无转化花费"
        elif blank: action, new = "单独低预算跑", "适配表查不到的ASIN一ASIN一活动验证"
        elif r["ASIN数"] == 1: action, new = "保留，按表现继续投放", "保留原单ASIN活动；ACOS持续高于平衡线时再调整"
        elif cid in high_mid or overlap < 80: action, new = "拆开，按适配范围重建", "主力ASIN一ASIN一活动；适配范围相同的长尾ASIN可放一起"
        elif overlap >= 80: action, new = "可以放一起，统一否词", "适配范围相近的ASIN可继续共用活动，广告组仍按ASIN分开"
        else: action, new = "先观察，暂不拆分", "继续看搜索词，出现中高冲突后再拆开"
        rows.append({"活动ID":cid, "原活动名":r["活动名称"], "ASIN数":r["ASIN数"], "ASIN列表":r["ASIN列表"],
            "高冲突词数":conf.get("高冲突数", 0), "中冲突词数":conf.get("中冲突数", 0), "低冲突词数":conf.get("低冲突数", 0),
            "错配花费":round(conf.get("错配花费", 0), 2), "错配订单":conf.get("错配订单", 0), "最低适配重叠率%":round(overlap, 1), "处置动作":action,
            "新建活动建议":new, "处理状态":"待运营确认", "统计周":week})
    final = pd.DataFrame(rows).sort_values(["错配花费", "ASIN数"], ascending=False)
    final.to_csv(out / "模块C_活动处置清单_最终.csv", index=False, encoding="utf-8-sig")
    evidence.to_csv(out / "模块C_搜索词实际错配明细.csv", index=False, encoding="utf-8-sig")
    # 重复活动：同一ASIN同周出现在两个及以上活动，需结合处置动作去重。
    exploded = final[["活动ID", "原活动名", "ASIN列表", "处置动作", "处理状态"]].assign(ASIN=lambda x: x["ASIN列表"].str.split("；")).explode("ASIN")
    repeated = exploded.groupby("ASIN").filter(lambda x: x["活动ID"].nunique() >= 2)
    dup = repeated.groupby("活动ID", as_index=False).agg(原活动名=("原活动名", "first"), 重复ASIN数=("ASIN", "nunique"),
        重复ASIN列表=("ASIN", lambda x: "；".join(sorted(set(x)))), 处置动作=("处置动作", "first"), 处理状态=("处理状态", "first"))
    related = repeated.groupby("ASIN")["活动ID"].apply(lambda x: "；".join(sorted(set(x)))).to_dict()
    dup["关联活动ID"] = dup["重复ASIN列表"].map(lambda s: "；".join(sorted(set(i for asin in s.split("；") for i in related[asin].split("；")))))
    dup.to_csv(out / "模块C_重复活动清单.csv", index=False, encoding="utf-8-sig")
    print(f"统计周={week}；活动={len(final)}；搜索词={len(terms)}；实际错配词={len(evidence)}；重复活动={len(dup)}")

if __name__ == "__main__":
    main()
