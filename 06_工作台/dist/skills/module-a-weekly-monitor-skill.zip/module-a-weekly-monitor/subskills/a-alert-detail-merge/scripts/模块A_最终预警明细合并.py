#!/usr/bin/env python3
"""模块 A 第三步：合并 Finance 预警与领星广告活动，输出最终预警明细表。

输入：
1. 分析结果/模块A_ASIN周环比监控表_{week}_vs_{prev}.csv（Finance 主表）
2. 原数据/模块A_领星ASIN广告指标周环比表.xlsx（领星补充原数据）

输出：仅保留已预警 ASIN，一行一个 ASIN；广告活动名称仅关联展示。
Finance 的单量、销售额、TACOS 与预警标记为经营口径；
曝光、点击、CTR、CVR、ACOS、ROAS 为领星广告归因口径。
"""
import argparse
import csv
from collections import defaultdict
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

SCRIPT_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = next((p for p in SCRIPT_DIR.parents if (p / "03_原数据").is_dir()), SCRIPT_DIR.parents[3])


def num(value):
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def mom(current, previous):
    if previous == 0:
        return "" if current == 0 else "N/A"
    return round((current - previous) / previous * 100, 2)


def rate(numerator, denominator):
    return round(numerator / denominator * 100, 2) if denominator else ""


def load_activity(path):
    """将领星每日活动记录汇总为 ASIN × 活动 × 周，避免每日记录重复展开。"""
    ws = load_workbook(path, read_only=True, data_only=True)["ASIN对应活动清单"]
    headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
    data = defaultdict(lambda: {"本周": defaultdict(float), "上周": defaultdict(float), "meta": {}})
    for values in ws.iter_rows(min_row=2, values_only=True):
        row = dict(zip(headers, values))
        asin, campaign_id, week = str(row.get("ASIN") or ""), str(row.get("活动ID") or ""), row.get("年周")
        if not asin or not campaign_id or week not in ("本周", "上周"):
            continue
        item = data[(asin, campaign_id)]
        for field in ("活动名称", "广告组合", "状态", "广告类型", "投放方式"):
            if row.get(field):
                item["meta"][field] = row[field]
        for field in ("曝光", "点击", "广告订单", "广告销售额", "广告花费"):
            item[week][field] += num(row.get(field))
    return data


def load_ads_by_asin(path):
    """广告指标先按 ASIN × 周汇总；活动名称只作为去重展示字段。"""
    activities = load_activity(path)
    data = defaultdict(lambda: {"本周": defaultdict(float), "上周": defaultdict(float), "campaigns": set()})
    for (asin, _campaign_id), activity in activities.items():
        item = data[asin]
        name = str(activity["meta"].get("活动名称") or "").strip()
        if name:
            item["campaigns"].add(name)
        for week in ("本周", "上周"):
            for field in ("曝光", "点击", "广告订单", "广告销售额", "广告花费"):
                item[week][field] += activity[week][field]
    return data


def main():
    parser = argparse.ArgumentParser(description="模块 A 最终预警明细合并")
    parser.add_argument("--week", default="2026-W35", help="比较周，如 2026-W35")
    parser.add_argument("--prev", default="2026-W34", help="对比周，如 2026-W34")
    parser.add_argument("--finance", help="Finance 预警主表 CSV")
    parser.add_argument("--ads", help="领星广告补充工作簿")
    parser.add_argument("--output", help="最终明细输出路径")
    args = parser.parse_args()

    finance_path = Path(args.finance) if args.finance else PACKAGE_ROOT / "04_分析结果" / f"模块A_ASIN周环比监控表_{args.week}_vs_{args.prev}.csv"
    ads_path = Path(args.ads) if args.ads else PACKAGE_ROOT / "03_原数据" / "模块A_领星ASIN广告指标周环比表.xlsx"
    output = Path(args.output) if args.output else PACKAGE_ROOT / "04_分析结果" / f"模块A_最终预警明细表_{args.week}_vs_{args.prev}.xlsx"

    with open(finance_path, encoding="utf-8-sig", newline="") as handle:
        warnings = [row for row in csv.DictReader(handle) if row.get("预警标记")]
    ads_by_asin = load_ads_by_asin(ads_path)

    fields = [
        "ASIN", "SKU集合", "广告活动名称", "预警标记",
        "上周单量", "上上周单量", "单量环比%", "上周销售额", "上上周销售额", "销售额环比%", "上周毛利润-实际", "上上周毛利润-实际", "上周毛利率%", "上上周毛利率%", "毛利率环比%", "上周TACOS%", "上上周TACOS%", "TACOS环比%",
        "上周曝光", "上上周曝光", "曝光环比%", "上周点击", "上上周点击", "点击环比%", "上周CTR%", "上上周CTR%", "CTR环比%",
        "上周CVR%", "上上周CVR%", "CVR环比%", "上周ACOS%", "上上周ACOS%", "ACOS环比%", "上周ROAS", "上上周ROAS", "ROAS环比%",
    ]
    result = []
    for finance in warnings:
        asin = finance["ASIN"]
        item = ads_by_asin.get(asin, {"本周": defaultdict(float), "上周": defaultdict(float), "campaigns": set()})
        current, previous = item["本周"], item["上周"]
        current_ctr, previous_ctr = rate(current["点击"], current["曝光"]), rate(previous["点击"], previous["曝光"])
        current_cvr, previous_cvr = rate(current["广告订单"], current["点击"]), rate(previous["广告订单"], previous["点击"])
        current_acos, previous_acos = rate(current["广告花费"], current["广告销售额"]), rate(previous["广告花费"], previous["广告销售额"])
        current_roas = round(current["广告销售额"] / current["广告花费"], 2) if current["广告花费"] else ""
        previous_roas = round(previous["广告销售额"] / previous["广告花费"], 2) if previous["广告花费"] else ""
        result.append({
            "ASIN": asin, "SKU集合": finance["SKU集合"], "广告活动名称": "\n".join(sorted(item["campaigns"])), "预警标记": finance["预警标记"],
            "上周单量": num(finance["上周单量"]), "上上周单量": num(finance["上上周单量"]), "单量环比%": finance["单量环比%"],
            "上周销售额": num(finance["上周销售额"]), "上上周销售额": num(finance["上上周销售额"]), "销售额环比%": finance["销售额环比%"],
            "上周毛利润-实际": finance.get("上周毛利润-实际", ""), "上上周毛利润-实际": finance.get("上上周毛利润-实际", ""), "上周毛利率%": finance.get("上周毛利率%", ""), "上上周毛利率%": finance.get("上上周毛利率%", ""), "毛利率环比%": finance.get("毛利率环比%", ""),
            "上周TACOS%": finance["上周TACOS%"], "上上周TACOS%": finance["上上周TACOS%"], "TACOS环比%": finance["TACOS环比%"],
            "上周曝光": current["曝光"], "上上周曝光": previous["曝光"], "曝光环比%": mom(current["曝光"], previous["曝光"]),
            "上周点击": current["点击"], "上上周点击": previous["点击"], "点击环比%": mom(current["点击"], previous["点击"]),
            "上周CTR%": current_ctr, "上上周CTR%": previous_ctr, "CTR环比%": mom(num(current_ctr), num(previous_ctr)),
            "上周CVR%": current_cvr, "上上周CVR%": previous_cvr, "CVR环比%": mom(num(current_cvr), num(previous_cvr)),
            "上周ACOS%": current_acos, "上上周ACOS%": previous_acos, "ACOS环比%": mom(num(current_acos), num(previous_acos)),
            "上周ROAS": current_roas, "上上周ROAS": previous_roas, "ROAS环比%": mom(num(current_roas), num(previous_roas)),
        })

    output.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "最终预警明细"
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(fields))
    ws.cell(1, 1, f"模块A｜ASIN周环比预警明细（{args.week} vs {args.prev}）")
    ws.cell(2, 1, f"范围：Finance 预警 ASIN {len(warnings)} 个；广告指标按 ASIN 汇总，广告活动名称仅关联展示。Finance 为经营口径，广告指标为领星归因口径。")
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(fields))
    ws.append([])
    ws.append(fields)
    for row in result:
        ws.append([row.get(field, "") for field in fields])
    for cell in ws[1]:
        cell.fill = PatternFill("solid", fgColor="17365D"); cell.font = Font(bold=True, color="FFFFFF"); cell.alignment = Alignment(horizontal="center")
    for cell in ws[2]:
        cell.fill = PatternFill("solid", fgColor="D9EAF7"); cell.alignment = Alignment(wrap_text=True)
    for cell in ws[4]:
        cell.fill = PatternFill("solid", fgColor="1F4E78"); cell.font = Font(bold=True, color="FFFFFF"); cell.alignment = Alignment(horizontal="center", wrap_text=True)
    ws.freeze_panes = "E5"
    for row_index in range(5, ws.max_row + 1):
        campaign_text = str(ws.cell(row_index, 3).value or "")
        warning_text = str(ws.cell(row_index, 4).value or "")
        campaign_lines = sum(max(1, (len(line) + 31) // 32) for line in campaign_text.split("\n"))
        warning_lines = max(warning_text.count("；") + 1, (len(warning_text) + 17) // 18)
        line_count = max(campaign_lines, warning_lines)
        ws.cell(row_index, 3).alignment = Alignment(vertical="top", wrap_text=True)
        ws.cell(row_index, 4).alignment = Alignment(vertical="top", wrap_text=True)
        ws.row_dimensions[row_index].height = min(105, max(24, 17 * line_count))
    for index in range(1, len(fields) + 1):
        letter = get_column_letter(index)
        ws.column_dimensions[letter].width = 36 if letter == "C" else (24 if letter in ("B", "D") else 13)
    wb.save(output)
    print(f"已输出 {len(result)} 条：{output}")


if __name__ == "__main__":
    main()
