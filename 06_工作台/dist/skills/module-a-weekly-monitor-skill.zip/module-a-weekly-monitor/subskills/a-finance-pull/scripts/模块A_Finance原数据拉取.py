#!/usr/bin/env python3
"""模块 A 第一步：只拉取 Finance 原始经营数据，不做任何预警判断。

口径：损益明细、shop_code2=VC1、operation_classification2=转向器、
platform_sale_code 以 B0 开头。默认拉取上周与上上周两个完整 ISO 自然周。
"""
import argparse
import csv
import json
import os
import shutil
import urllib.request
import subprocess
from datetime import date, timedelta
from pathlib import Path

FINANCE_TOOL = "bi-getdata-finance.query_smartbi_data"
FINANCE_SERVER = "bi-getdata-finance"
MCP_BASE_URL = "https://higress.suncentgroup.com/mcp-servers"
DIMENSIONS = ["period_id_d_Week2", "operation_classification2", "platform_sale_code", "sku"]
MEASURES = [
    "sales_qty_m", "sales_amount_m", "gross_profit_real_m",
    "ad_spend_sp_m", "ad_spend_sd_m", "ad_spend_sb_m",
]
SCRIPT_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = SCRIPT_DIR.parents[3]
DEFAULT_OUTPUT_DIR = PACKAGE_ROOT / "03_原数据"
MCPORTER_COMMAND = next((path for path in (
    os.environ.get("MCPORTER_COMMAND"), shutil.which("mcporter.cmd"),
    str(Path.home() / "AppData" / "Local" / "pnpm" / "bin" / "mcporter.CMD"),
) if path and Path(path).is_file()), "mcporter")


def default_weeks(reference=None):
    today = reference or date.today()
    latest_sunday = today - timedelta(days=today.weekday() + 1)
    latest_monday = latest_sunday - timedelta(days=6)
    previous_monday = latest_monday - timedelta(days=7)
    to_iso = lambda day: f"{day.isocalendar().year}-W{day.isocalendar().week:02d}"
    return to_iso(latest_monday), to_iso(previous_monday)


def parse_json(text):
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end < start:
            raise RuntimeError(f"Finance 返回无法解析：{text[:500]}")
        return json.loads(text[start:end + 1])


def mcp_query(tool, request):
    """使用本机 SUNCENT_BI_TOKEN 直连 MCP，避开 mcporter 的 OAuth 交互。"""
    token = os.environ.get("SUNCENT_BI_TOKEN")
    if not token:
        raise RuntimeError("未检测到 SUNCENT_BI_TOKEN，无法调用 Finance BI MCP。")
    url = f"{MCP_BASE_URL}/{FINANCE_SERVER}"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
    def post(payload):
        stage = payload["method"]
        print(f"[BI Finance] {stage} 开始", flush=True)
        response = urllib.request.urlopen(urllib.request.Request(url, data=json.dumps(payload).encode(), headers=headers, method="POST"), timeout=60)
        print(f"[BI Finance] {stage} 已连接（HTTP {response.status}）", flush=True)
        if response.headers.get("mcp-session-id"):
            headers["mcp-session-id"] = response.headers["mcp-session-id"]
        if "text/event-stream" in response.headers.get("content-type", ""):
            for raw_line in response:
                line = raw_line.decode("utf-8").strip()
                if line.startswith("data:") and line[5:].strip():
                    return json.loads(line[5:].strip())
            return {}
        body = response.read().decode("utf-8")
        return json.loads(body) if body.strip() else {}
    post({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-03-26", "capabilities": {}, "clientInfo": {"name": "module-a-finance", "version": "1.0"}}})
    post({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})
    result = post({"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": tool, "arguments": request}})
    texts = [item.get("text", "") for item in (result.get("result") or {}).get("content", []) if item.get("type") == "text"]
    if not texts:
        raise RuntimeError("Finance BI MCP 未返回文本数据")
    return parse_json(texts[-1])


def fetch_week(week):
    request = {
        "dimensions": DIMENSIONS,
        "measures": MEASURES,
        "filters": [
            {"name": "shop_code2", "operation": "EQUALS", "values": ["VC1"]},
            {"name": "period_id_d_Week2", "operation": "EQUALS", "values": [week]},
            {"name": "operation_classification2", "operation": "EQUALS", "values": ["转向器"]},
            {"name": "platform_sale_code", "operation": "STARTWITH", "values": ["B0"]},
        ],
        "limit": -1,
    }
    print(f"[BI Finance] 请求 {week} 数据", flush=True)
    payload = mcp_query("query_smartbi_data", request)
    if payload.get("error"):
        raise RuntimeError(f"Finance 查询返回错误：{payload['error']}")
    data = payload.get("data") or payload.get("result") or []
    if isinstance(data, str):
        data = parse_json(data).get("data", [])
    return data if isinstance(data, list) else []


def get_value(row, technical, alias):
    return row.get(technical, row.get(alias, ""))


def main():
    parser = argparse.ArgumentParser(description="模块 A Finance 原数据拉取")
    parser.add_argument("--week", help="比较周，如 2026-W35；默认最近完整自然周")
    parser.add_argument("--prev", help="对比周，如 2026-W34；默认比较周的前一自然周")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    args = parser.parse_args()
    default_week, default_prev = default_weeks()
    week, prev = args.week or default_week, args.prev or default_prev

    output_rows = []
    for current_week in (week, prev):
        rows = fetch_week(current_week)
        print(f"已拉取 {current_week}：{len(rows)} 条底层记录", flush=True)
        for row in rows:
            asin = str(get_value(row, "platform_sale_code", "平台销售编码")).strip()
            if not asin.startswith("B0"):
                continue
            output_rows.append({
                "年周": get_value(row, "period_id_d_Week2", "年周"),
                "业务分类": get_value(row, "operation_classification2", "业务分类"),
                "ASIN": asin,
                "SKU": get_value(row, "sku", "商品编码"),
                "出库销量": get_value(row, "sales_qty_m", "出库销量"),
                "出库销售额": get_value(row, "sales_amount_m", "出库销售额"),
                "毛利润-实际": get_value(row, "gross_profit_real_m", "毛利润-实际"),
                "广告花费-SP": get_value(row, "ad_spend_sp_m", "广告花费-SP"),
                "广告花费-SD": get_value(row, "ad_spend_sd_m", "广告花费-SD"),
                "广告花费-SB": get_value(row, "ad_spend_sb_m", "广告花费-SB"),
            })

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"模块A_Finance原始数据_{week}_vs_{prev}.csv"
    fields = ["年周", "业务分类", "ASIN", "SKU", "出库销量", "出库销售额", "毛利润-实际", "广告花费-SP", "广告花费-SD", "广告花费-SB"]
    with open(output, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(output_rows)
    print(f"原始数据已保存：{output}（{len(output_rows)} 行）")


if __name__ == "__main__":
    main()
