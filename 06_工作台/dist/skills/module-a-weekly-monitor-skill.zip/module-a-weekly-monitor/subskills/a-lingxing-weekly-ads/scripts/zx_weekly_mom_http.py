#!/usr/bin/env python3
"""模块 A 广告指标补充（领星 HTTP + MCP）。
领星 HTTP 直连 spProductAdReports（全量主账户）→ 本地按转向器活动过滤 → ASIN 广告指标周环比；
领星 MCP ad_campaign_report → 活动组合、状态、类型和投放方式。
默认窗口为上周一至周日 vs 上上周一至周日；可用 --week-end 手动指定比较周的周日。

本脚本仅补充曝光、点击、CTR、CVR、ACOS、ROAS、广告花费及活动映射。
订单和销售额为广告归因口径，不能替代 Finance 的出库销量/总销售额，也不能单独触发模块 A 预警。
输出: ~/lingxing_scan/转向器ASIN周环比监控表.xlsx
"""
import sys, json, time, re, os, shutil, argparse, subprocess, base64, hashlib, urllib.parse, urllib.request
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = next((p for p in SCRIPT_DIR.parents if (p / "03_原数据").is_dir()), SCRIPT_DIR.parents[3])
MCPORTER_COMMAND = next((path for path in (
    os.environ.get("MCPORTER_COMMAND"), shutil.which("mcporter.cmd"),
    str(Path.home() / "AppData" / "Local" / "pnpm" / "bin" / "mcporter.CMD"),
) if path and Path(path).is_file()), "mcporter")

# 凭据只从环境变量或指定 .env 读取，绝不写入脚本。
def load_env_file(path):
    if not path or not Path(path).is_file():
        return
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if line.startswith('LINGXING_') and '=' in line:
            key, value = line.split('=', 1)
            os.environ.setdefault(key, value.strip().strip('"').strip("'"))


class LingxingOpenAPIClient:
    """领星 OpenAPI 签名客户端，不依赖资料包外的旧客户端文件。"""
    BASE_URL = 'https://openapi.lingxing.com'

    def __init__(self):
        self.app_id = ''
        self.access_token = ''

    def ensure_access_token(self):
        self.app_id = os.environ.get('LINGXING_APP_ID', '')
        app_secret = os.environ.get('LINGXING_APP_SECRET', '')
        if not self.app_id or not app_secret:
            raise RuntimeError('未找到领星凭据：请设置 LINGXING_APP_ID 与 LINGXING_APP_SECRET，或传入 --env-file。')
        url = f'{self.BASE_URL}/api/auth-server/oauth/access-token?appId={self.app_id}&appSecret={urllib.parse.quote(app_secret)}'
        try:
            with urllib.request.urlopen(urllib.request.Request(url, data=b'', method='POST'), timeout=30) as response:
                payload = json.loads(response.read())
        except Exception as exc:
            raise RuntimeError(f'领星 OpenAPI 获取访问令牌失败：{exc}') from exc
        if str(payload.get('code')) not in ('0', '200') or not (payload.get('data') or {}).get('access_token'):
            raise RuntimeError(f'领星 OpenAPI 获取访问令牌失败：{payload.get("msg") or payload}')
        self.access_token = payload['data']['access_token']

    def sign(self, params):
        # 仅旧领星 HTTP 路径需要此依赖；BI 正式入口无需安装加密库。
        from Crypto.Cipher import AES
        from Crypto.Util.Padding import pad
        def text(value):
            if isinstance(value, (dict, list)):
                return json.dumps(value, ensure_ascii=False, separators=(',', ':'), sort_keys=True)
            return str(value)
        canonical = '&'.join(f'{key}={text(value)}' for key, value in sorted(params.items()) if value != '')
        digest = hashlib.md5(canonical.encode()).hexdigest().upper()
        encrypted = AES.new(self.app_id.encode(), AES.MODE_ECB).encrypt(pad(digest.encode(), 16))
        return base64.b64encode(encrypted).decode()

    def post_json(self, path, payload, extra_headers=None):
        timestamp = str(int(time.time()))
        auth = {'access_token': self.access_token, 'app_key': self.app_id, 'timestamp': timestamp}
        query = dict(auth)
        query['sign'] = urllib.parse.quote(self.sign({**auth, **payload}), safe='')
        request = urllib.request.Request(
            f'{self.BASE_URL}{path}?{urllib.parse.urlencode(query)}',
            data=json.dumps(payload).encode(), method='POST',
        )
        request.add_header('Content-Type', 'application/json')
        for key, value in (extra_headers or {}).items():
            request.add_header(key, value)
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                return json.loads(response.read())
        except Exception as exc:
            raise RuntimeError(f'领星 OpenAPI 请求失败：{exc}') from exc


PROFILE_ID = 1447622540479139
ASIN_INFO = str(SCRIPT_DIR / 'asin_info.json')
ZX_RESULTS = str(SCRIPT_DIR / 'zx_asin_results.json')
OUT_XLSX = PACKAGE_ROOT / '03_原数据' / '模块A_领星ASIN广告指标周环比表.xlsx'
CACHE = str(SCRIPT_DIR / 'wmom_http_cache.json')


def metric_value(row, *keys):
    """按字段优先级读取数值；领星日报的花费字段实际为 cost。"""
    for key in keys:
        value = row.get(key)
        if value not in (None, ''):
            try:
                return float(value)
            except (TypeError, ValueError):
                return 0.0
    return 0.0


def report_rows(payload):
    """兼容 MCP action 的常见返回结构，抽取明细行。"""
    if not isinstance(payload, dict):
        return [], None
    data = payload.get('data') or {}
    if isinstance(data, dict):
        inner = data.get('data') or data.get('list') or data
        total = data.get('recordsFiltered') or data.get('total')
        if isinstance(inner, dict):
            return inner.get('list') or inner.get('data') or [], inner.get('total') or total
        return inner if isinstance(inner, list) else [], total
    return data if isinstance(data, list) else [], None


def parse_mcp_output(completed, context):
    raw = completed.stdout or completed.stderr
    start, end = raw.find('{'), raw.rfind('}')
    if completed.returncode or start < 0 or end < start:
        raise RuntimeError(f'{context}失败：{raw[:300]}')
    try:
        payload = json.loads(raw[start:end + 1])
    except json.JSONDecodeError as exc:
        raise RuntimeError(f'{context}返回无法解析：{exc}') from exc
    if isinstance(payload, dict) and (payload.get('success') is False or str(payload.get('code', 0)) not in ('0', 'None')):
        raise RuntimeError(f'{context}失败：{payload.get("msg") or payload}')
    return payload


def nested_value(value, key):
    if isinstance(value, dict):
        if value.get(key) not in (None, ''):
            return value[key]
        for item in value.values():
            found = nested_value(item, key)
            if found not in (None, ''):
                return found
    elif isinstance(value, list):
        for item in value:
            found = nested_value(item, key)
            if found not in (None, ''):
                return found
    return None


def campaign_metadata_from_mcp(command, server, profile_id, report_date, campaign_ids):
    """通过领星 MCP 活动报表补齐活动属性，按活动 ID 返回。"""
    search = subprocess.run(
        [command, 'call', f'{server}.search', '--args', json.dumps({'toolId': 'ad_campaign_report'})],
        capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=180,
    )
    spec = parse_mcp_output(search, '领星 MCP 活动报表 Schema 查询')
    catalog_version = nested_value(spec, 'catalogVersion')
    schema_version = nested_value(spec, 'schemaVersion')
    tool_version_id = nested_value(spec, 'toolVersionId')
    if not all((catalog_version, schema_version, tool_version_id)):
        raise RuntimeError('领星 MCP 活动报表 Schema 缺少版本信息，已停止生成。')

    metadata, page, page_size = {}, 1, 500
    while True:
        params = {
            'profile_ids': [str(profile_id)], 'report_date': report_date,
            'page': page, 'length': page_size, 'sort_field': 'spends', 'sort_type': 'desc',
        }
        action = {
            'toolId': 'ad_campaign_report', 'catalogVersion': catalog_version,
            'schemaVersion': schema_version, 'toolVersionId': int(tool_version_id),
            'params': params,
        }
        completed = subprocess.run(
            [command, 'call', f'{server}.action', '--args', json.dumps(action, ensure_ascii=False)],
            capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=180,
        )
        rows, total = report_rows(parse_mcp_output(completed, f'领星 MCP 活动报表获取（第 {page} 页）'))
        valid_rows = [row for row in rows if str(row.get('campaign_id') or '') in campaign_ids]
        for row in valid_rows:
            campaign_id = str(row['campaign_id'])
            metadata[campaign_id] = {
                '活动名称': row.get('campaign_name') or row.get('name') or '',
                '广告组合': row.get('portfolio_name') or row.get('portfolio') or '',
                '状态': row.get('state') or row.get('campaign_state') or row.get('status') or '',
                '广告类型': row.get('ads_type') or row.get('ad_type') or row.get('campaign_type') or '',
                '投放方式': row.get('targeting_type') or row.get('target_type') or row.get('targeting') or '',
            }
        if not rows or len(rows) < page_size or (total is not None and page * page_size >= int(total)):
            break
        page += 1
    if not metadata:
        raise RuntimeError('领星 MCP 活动报表未返回任何转向器活动；已停止生成，避免再次写入空活动属性。')
    print(f'活动属性：MCP 报表匹配 {len(metadata)} 个转向器活动', flush=True)
    return metadata

def week_windows(week_end_text=None):
    """返回比较周和前一周的日列表；默认比较最近完整自然周。"""
    if week_end_text:
        latest_sunday = date.fromisoformat(week_end_text)
        if latest_sunday.weekday() != 6:
            raise ValueError('--week-end 必须是周日，格式为 YYYY-MM-DD')
    else:
        today = date.today()
        latest_sunday = today - timedelta(days=today.weekday() + 1)
    latest_monday = latest_sunday - timedelta(days=6)
    previous_sunday = latest_monday - timedelta(days=1)
    previous_monday = previous_sunday - timedelta(days=6)
    dates = lambda start: [(start + timedelta(days=offset)).isoformat() for offset in range(7)]
    return dates(latest_monday), dates(previous_monday)

def derive_spu(gc):
    s = gc.strip()
    m = re.match(r'^[A-Za-z]{2}(.+)$', s)
    if m: s = m.group(1)
    if s.endswith('0'): s = s[:-1]
    return s

def fetch_day(client, date):
    """拉一天全量，返回行列表（转向器活动过滤）"""
    zx_ids = json.load(open(ZX_RESULTS, encoding='utf-8'))
    zx_set = set(zx_ids.keys())
    rows = []
    offset, total = 0, None
    while True:
        # 历史日期的全店报表在 1,000 行分页下会频繁读取超时；500 行更稳定。
        payload = {"profile_id": PROFILE_ID, "report_date": date, "show_detail": 1,
                   "offset": offset, "length": 500}
        try:
            resp = client.post_json('/pb/openapi/newad/spProductAdReports', payload,
                                    extra_headers={"X-API-VERSION": "2"})
        except Exception as e:
            print(f'  [{date}] offset={offset} 异常重试: {str(e)[:80]}', flush=True)
            time.sleep(3); continue
        batch = resp.get('data') or []
        total = resp.get('total')
        # 过滤转向器活动
        kept = [r for r in batch if str(r.get('campaign_id')) in zx_set]
        # OpenAPI 日报通常只有 campaign_id；用标签缓存回填活动名称。
        for r in kept:
            meta = zx_ids.get(str(r.get('campaign_id'))) or {}
            if isinstance(meta, dict) and not r.get('name'):
                r['name'] = meta.get('name', '')
        rows.extend(kept)
        if not batch or (total is not None and offset + len(batch) >= total):
            break
        offset += len(batch)
        time.sleep(0.3)
    print(f'  [{date}] 全量{total}行 → 转向器保留 {len(rows)} 行', flush=True)
    return rows

def main():
    global PROFILE_ID, ASIN_INFO, ZX_RESULTS
    ap = argparse.ArgumentParser()
    ap.add_argument('--week-end', default=None, help='比较周的周日（YYYY-MM-DD）；默认最近完整自然周的周日')
    ap.add_argument('--env-file', default=os.environ.get('LINGXING_ENV_FILE', str(SCRIPT_DIR / '.env')), help='领星 API 凭据 .env 文件（默认脚本目录 .env）')
    ap.add_argument('--profile-id', type=int, default=PROFILE_ID, help='领星店铺 Profile ID')
    ap.add_argument('--asin-info', default=ASIN_INFO, help='活动 ASIN 映射缓存 JSON')
    ap.add_argument('--campaigns', default=ZX_RESULTS, help='转向器活动清单 JSON（campaign_id 为键）')
    ap.add_argument('--mcp-command', default='mcporter', help='领星 MCP 命令（默认 mcporter）')
    ap.add_argument('--mcp-server', default='lingxing-mcp', help='mcporter 中的领星 MCP 服务名')
    ap.add_argument('--activity-meta-mode', choices=('auto', 'mcp', 'none'), default='auto',
                    help='活动属性来源：auto（MCP 失败时继续 API 指标拉取）、mcp（失败即停止）、none（不拉属性）')
    ap.add_argument('--refresh', action='store_true', help='忽略本地日报缓存，重新通过领星 API 拉取 14 天数据')
    args = ap.parse_args()
    load_env_file(args.env_file)
    PROFILE_ID, ASIN_INFO, ZX_RESULTS = args.profile_id, args.asin_info, args.campaigns
    week_dates, prev_dates = week_windows(args.week_end)

    # 缓存（断点续跑）
    cache = {}
    if os.path.exists(CACHE) and not args.refresh:
        cache = json.load(open(CACHE, encoding='utf-8'))

    client = LingxingOpenAPIClient()
    client.ensure_access_token()

    all_rows = {'week': [], 'prev': []}
    for date in week_dates:
        if date not in cache:
            cache[date] = fetch_day(client, date)
            json.dump(cache, open(CACHE, 'w', encoding='utf-8'), ensure_ascii=False)
        all_rows['week'].extend(cache[date])
    for date in prev_dates:
        if date not in cache:
            cache[date] = fetch_day(client, date)
            json.dump(cache, open(CACHE, 'w', encoding='utf-8'), ensure_ascii=False)
        all_rows['prev'].extend(cache[date])

    print(f'本周行数: {len(all_rows["week"])} | 上周行数: {len(all_rows["prev"])}', flush=True)
    campaign_rows = json.load(open(ZX_RESULTS, encoding='utf-8'))
    campaign_ids = set(campaign_rows)
    campaign_metadata = {}
    if args.activity_meta_mode != 'none':
        try:
            campaign_metadata = campaign_metadata_from_mcp(
                args.mcp_command, args.mcp_server, PROFILE_ID,
                f'{prev_dates[0]} - {week_dates[-1]}', campaign_ids,
            )
        except (RuntimeError, OSError) as exc:
            if args.activity_meta_mode == 'mcp':
                raise
            print(f'活动属性 MCP 未获取：{exc}；继续使用领星 API 刷新广告指标。', flush=True)

    def agg(rows):
        a = defaultdict(lambda: {'imp': 0, 'clk': 0, 'ord': 0, 'sal': 0.0, 'spd': 0.0})
        for r in rows:
            asin = (r.get('asin') or '').strip()
            if not asin: continue
            x = a[asin]
            for k1, k2 in [('imp','impressions'), ('clk','clicks'), ('ord','orders')]:
                try: x[k1] += int(float(r.get(k2) or 0))
                except: pass
            x['sal'] += metric_value(r, 'sales')
            x['spd'] += metric_value(r, 'spends', 'cost')
        return a

    cur, prev = agg(all_rows['week']), agg(all_rows['prev'])

    info = json.load(open(ASIN_INFO, encoding='utf-8'))
    asin_gc = {}
    for asin, v in info.items():
        if isinstance(v, dict):
            skus = v.get('sku')
            if isinstance(skus, list) and skus:
                asin_gc[asin] = str(skus[0])
            elif isinstance(skus, str):
                inner = skus.strip("[]'\" ")
                asin_gc[asin] = inner.split(',')[0].strip()

    rows_out = []
    ZERO = {'imp': 0, 'clk': 0, 'ord': 0, 'sal': 0.0, 'spd': 0.0}
    for asin in sorted(set(cur) | set(prev)):
        c, p = cur.get(asin, ZERO), prev.get(asin, ZERO)
        if not (c['ord'] or p['ord'] or c['spd'] or p['spd']):
            continue
        gc = asin_gc.get(asin, '')
        spu = derive_spu(gc) if gc else ''
        def pct(cv, pv):
            if pv is None or pv == 0: return '' if not cv else 'N/A'
            if cv is None: return ''
            return f'{(cv - pv) / pv * 100:+.1f}%'
        def cv(x):
            return round(x, 2) if x else 0
        rows_out.append({
            'asin': asin, '商品编码': gc, '产品编码': spu,
            '本周单量': c['ord'], '上周单量': p['ord'], '单量环比': c['ord'] - p['ord'],
            '本周销售额': cv(c['sal']), '上周销售额': cv(p['sal']), '销售额环比': pct(c['sal'], p['sal']),
            '本周曝光': c['imp'], '上周曝光': p['imp'], '曝光环比': pct(c['imp'], p['imp']),
            '本周点击': c['clk'], '上周点击': p['clk'], '点击环比': pct(c['clk'], p['clk']),
            '本周CTR%': cv(c['clk'] / c['imp'] * 100) if c['imp'] else '', '上周CTR%': cv(p['clk'] / p['imp'] * 100) if p['imp'] else '',
            '本周CVR%': cv(c['ord'] / c['clk'] * 100) if c['clk'] else '', '上周CVR%': cv(p['ord'] / p['clk'] * 100) if p['clk'] else '',
            '本周ACOS%': cv(c['spd'] / c['sal'] * 100) if c['sal'] else '', '上周ACOS%': cv(p['spd'] / p['sal'] * 100) if p['sal'] else '',
            '本周ROAS': cv(c['sal'] / c['spd']) if c['spd'] else '', '上周ROAS': cv(p['sal'] / p['spd']) if p['spd'] else '',
            '本周TACOS%': '', '上周TACOS%': '', '本周毛利率%': '', '上周毛利率%': '',
            '本周花费': cv(c['spd']), '上周花费': cv(p['spd']),
        })

    by_spu = defaultdict(lambda: {'co': 0, 'po': 0, 'asins': []})
    for r in rows_out:
        spu = r['产品编码'] or '无编码'
        by_spu[spu]['co'] += r['本周单量']
        by_spu[spu]['po'] += r['上周单量']
        if r['本周单量'] or r['上周单量']:
            by_spu[spu]['asins'].append(r['asin'])
    warns = []
    for spu, v in sorted(by_spu.items(), key=lambda x: x[1]['po'] - x[1]['co'], reverse=True):
        drop = v['po'] - v['co']
        if drop > 3:
            warns.append({'产品编码': spu, '上周单量': v['po'], '本周单量': v['co'],
                          '下滑单量': drop, '涉及ASIN数': len(v['asins']), 'ASIN': ' '.join(v['asins'][:8])})

    print(f'\n明细 ASIN 行: {len(rows_out)} | 预警商品编码: {len(warns)}')
    for w in warns[:15]:
        print(f"  ⚠️ {w['产品编码']}: 上周{w['上周单量']} → 本周{w['本周单量']}（下滑{w['下滑单量']}）")

    # Excel
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    ws = wb.active; ws.title = 'ASIN周环比明细'
    hdr = list(rows_out[0].keys()) if rows_out else []
    ws.append(hdr)
    for r in rows_out:
        ws.append([r.get(k, '') for k in hdr])
    for i in range(1, len(hdr) + 1):
        ws.column_dimensions[get_column_letter(i)].width = 12
    ws.freeze_panes = 'A2'

    # 保留活动粒度：后续仅需按 ASIN 与周窗口筛选，即可查看该 ASIN 的全部对应活动。
    ws_activity = wb.create_sheet('ASIN对应活动清单')
    activity_headers = ['年周', 'ASIN', '活动ID', '活动名称', '广告组合', '状态', '广告类型', '投放方式',
                        '曝光', '点击', 'CTR%', 'CVR%', 'ACOS%', 'ROAS', '广告订单', '广告销售额', '广告花费']
    ws_activity.append(activity_headers)
    for label, source_rows in [('本周', all_rows['week']), ('上周', all_rows['prev'])]:
        for r in source_rows:
            asin = str(r.get('asin') or '').strip()
            if not asin.startswith('B0'):
                continue
            imp, clk = metric_value(r, 'impressions'), metric_value(r, 'clicks')
            orders, sales, spends = metric_value(r, 'orders'), metric_value(r, 'sales'), metric_value(r, 'spends', 'cost')
            campaign_id = str(r.get('campaign_id') or '')
            meta = campaign_metadata.get(campaign_id, {})
            campaign_name = meta.get('活动名称') or r.get('name') or (campaign_rows.get(campaign_id, {}).get('name', '') if isinstance(campaign_rows.get(campaign_id), dict) else '')
            ws_activity.append([label, asin, campaign_id, campaign_name, meta.get('广告组合', ''),
                                meta.get('状态', ''), meta.get('广告类型', ''), meta.get('投放方式', ''), imp, clk,
                                round(clk / imp * 100, 2) if imp else '', round(orders / clk * 100, 2) if clk else '',
                                round(spends / sales * 100, 2) if sales else '', round(sales / spends, 2) if spends else '',
                                orders, sales, spends])
    ws_activity.freeze_panes = 'A2'
    for i, width in enumerate([12, 14, 16, 42, 28, 12, 12, 12, 12, 10, 10, 10, 10, 10, 12, 14, 12], 1):
        ws_activity.column_dimensions[get_column_letter(i)].width = width

    ws2 = wb.create_sheet('商品编码广告单量变化')
    ws2.append(['产品编码', '上周广告订单', '本周广告订单', '广告订单变化', '涉及ASIN数', 'ASIN'])
    for w in warns:
        ws2.append([w['产品编码'], w['上周单量'], w['本周单量'], w['下滑单量'], w['涉及ASIN数'], w['ASIN']])
    for i, w in enumerate([12, 10, 10, 10, 10, 90], 1):
        ws2.column_dimensions[get_column_letter(i)].width = w

    ws3 = wb.create_sheet('口径说明')
    for l in [['项目', '说明'],
              ['周窗口', f'本周={week_dates[0]}~{week_dates[-1]}；上周={prev_dates[0]}~{prev_dates[-1]}（自然周）'],
              ['执行口径', '每周一运行时，“本周”列为刚结束的上周，“上周”列为上上周；不会包含未结束的当前周'],
              ['数据源', '领星 HTTP spProductAdReports（指标）+ MCP ad_campaign_report（活动属性）'],
              ['指标', '单量/销售额/曝光/点击/CTR/CVR/ACOS/ROAS 为广告口径'],
              ['触发条件', '无；正式预警由 Finance 主表按出库销量/总销售额/TACOS 判定'],
              ['TACOS/毛利率', '需 BI 补填（当前留空）'],
              ['备注', 'MCP 网关 8/25 改版（help→search→action），本脚本走 HTTP 直连备用通道']]:
        ws3.append(l)
    ws3.column_dimensions['A'].width = 16
    ws3.column_dimensions['B'].width = 95

    OUT_XLSX.parent.mkdir(parents=True, exist_ok=True)
    wb.save(OUT_XLSX)
    print(f'\n输出: {OUT_XLSX}')

if False:  # 保留原领星 HTTP 实现供历史排查；正式入口见下方 BI 版本。
    main()


# 模块 A 正式广告原数据：BI 综合数据模型。
# 活动名称只在原始数据和 ASIN 关联展示中保留，绝不作为指标汇总粒度。
COMPANY_TOOL = "bi-getdata-company-all.query_smartbi_data"
COMPANY_SERVER = "bi-getdata-company-all"
MCP_BASE_URL = "https://higress.suncentgroup.com/mcp-servers"
BI_DIMENSIONS = ["yyyyww_Week", "shop_code", "operation_classification", "platform_sale_code", "sku", "campaign_name2"]
BI_MEASURES = ["impressions_m", "clicks_m", "spend_m", "ad_sales_qty_m", "ad_sales_amount_m"]


def _bi_week_pair(reference=None):
    today = reference or date.today()
    latest_sunday = today - timedelta(days=today.weekday() + 1)
    latest_monday = latest_sunday - timedelta(days=6)
    previous_monday = latest_monday - timedelta(days=7)
    to_iso = lambda day: f"{day.isocalendar().year}-W{day.isocalendar().week:02d}"
    return to_iso(latest_monday), to_iso(previous_monday)


def _bi_payload(value):
    if isinstance(value, str):
        start, end = value.find("{"), value.rfind("}")
        if start < 0 or end < start:
            raise RuntimeError(f"BI 返回无法解析：{value[:500]}")
        value = value[start:end + 1]
    payload = json.loads(value) if isinstance(value, str) else value
    if payload.get("error"):
        raise RuntimeError(f"BI 查询返回错误：{payload['error']}")
    data = payload.get("data") or payload.get("result") or []
    if isinstance(data, str):
        data = json.loads(data).get("data", [])
    if isinstance(data, dict):
        data = data.get("data") or data.get("list") or []
    return data if isinstance(data, list) else []


def _bi_value(row, technical, label):
    return row.get(technical, row.get(label, ""))


def _mcp_company_query(request):
    token = os.environ.get("SUNCENT_BI_TOKEN")
    if not token:
        raise RuntimeError("未检测到 SUNCENT_BI_TOKEN，无法调用广告 BI MCP。")
    url = f"{MCP_BASE_URL}/{COMPANY_SERVER}"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
    def post(payload):
        stage = payload["method"]
        print(f"[BI 广告] {stage} 开始", flush=True)
        response = urllib.request.urlopen(urllib.request.Request(url, data=json.dumps(payload).encode(), headers=headers, method="POST"), timeout=60)
        print(f"[BI 广告] {stage} 已连接（HTTP {response.status}）", flush=True)
        if response.headers.get("mcp-session-id"):
            headers["mcp-session-id"] = response.headers["mcp-session-id"]
        if "text/event-stream" in response.headers.get("content-type", ""):
            for raw_line in response:
                line = raw_line.decode("utf-8").strip()
                if line.startswith("data:") and line[5:].strip():
                    return json.loads(line[5:].strip())
            return {}
        body = response.read().decode("utf-8")
        return json.loads(body) if body.strip() else {}
    post({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-03-26", "capabilities": {}, "clientInfo": {"name": "module-a-company", "version": "1.0"}}})
    post({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})
    result = post({"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": "query_smartbi_data", "arguments": request}})
    texts = [item.get("text", "") for item in (result.get("result") or {}).get("content", []) if item.get("type") == "text"]
    if not texts:
        raise RuntimeError("广告 BI MCP 未返回文本数据")
    return _bi_payload(texts[-1])


def _fetch_bi_week(week):
    request = {
        "dimensions": BI_DIMENSIONS,
        "measures": BI_MEASURES,
        "filters": [
            {"name": "shop_code", "operation": "EQUALS", "values": ["VC1"]},
            {"name": "yyyyww_Week", "operation": "EQUALS", "values": [week]},
            {"name": "operation_classification", "operation": "EQUALS", "values": ["转向器"]},
            {"name": "platform_sale_code", "operation": "STARTWITH", "values": ["B0"]},
        ],
        "limit": -1,
    }
    print(f"[BI 广告] 请求 {week} 数据", flush=True)
    return _mcp_company_query(request)


def diagnose_filters(week):
    """逐层检查 BI 广告筛选，避免将错误筛选结果保存为空文件。"""
    base = {"dimensions": BI_DIMENSIONS, "measures": BI_MEASURES, "limit": 20}
    stages = [
        ("仅年周", [{"name": "yyyyww_Week", "operation": "EQUALS", "values": [week]}]),
        ("年周 + 店铺", [{"name": "yyyyww_Week", "operation": "EQUALS", "values": [week]}, {"name": "shop_code", "operation": "EQUALS", "values": ["VC1"]}]),
        ("年周 + 店铺 + 业务分类", [{"name": "yyyyww_Week", "operation": "EQUALS", "values": [week]}, {"name": "shop_code", "operation": "EQUALS", "values": ["VC1"]}, {"name": "operation_classification", "operation": "EQUALS", "values": ["转向器"]}]),
        ("完整筛选", [{"name": "yyyyww_Week", "operation": "EQUALS", "values": [week]}, {"name": "shop_code", "operation": "EQUALS", "values": ["VC1"]}, {"name": "operation_classification", "operation": "EQUALS", "values": ["转向器"]}, {"name": "platform_sale_code", "operation": "STARTWITH", "values": ["B0"]}]),
    ]
    for label, filters in stages:
        rows = _mcp_company_query({**base, "filters": filters})
        print(f"[诊断] {label}: {len(rows)} 条（limit=20）", flush=True)


def _num(value):
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def _rate(numerator, denominator):
    return round(numerator / denominator * 100, 2) if denominator else ""


def _change(current, previous):
    if not previous:
        return "" if not current else "N/A"
    return f"{(current - previous) / previous * 100:+.1f}%"


def bi_main():
    parser = argparse.ArgumentParser(description="模块A广告原始数据拉取（BI 综合数据模型）")
    parser.add_argument("--week", help="比较周，如 2026-W35；默认最近完整自然周")
    parser.add_argument("--prev", help="对比周，如 2026-W34；默认比较周的前一自然周")
    parser.add_argument("--week-end", help="兼容旧调用：比较周周日，YYYY-MM-DD")
    parser.add_argument("--source", choices=("lingxing", "bi"), default="lingxing", help="广告数据源；默认领星 API，BI 仅保留为备选")
    parser.add_argument("--diagnose", action="store_true", help="逐层检查广告 BI 筛选，不生成文件")
    parser.add_argument("--output-dir", default=str(OUT_XLSX.parent))
    args = parser.parse_args()
    default_week, default_prev = _bi_week_pair()
    if args.week_end:
        sunday = date.fromisoformat(args.week_end)
        if sunday.weekday() != 6:
            raise ValueError("--week-end 必须是周日，格式为 YYYY-MM-DD")
        monday = sunday - timedelta(days=6)
        args.week = f"{monday.isocalendar().year}-W{monday.isocalendar().week:02d}"
        previous_monday = monday - timedelta(days=7)
        args.prev = f"{previous_monday.isocalendar().year}-W{previous_monday.isocalendar().week:02d}"
    week, prev = args.week or default_week, args.prev or default_prev

    if args.source == "lingxing":
        # 复用已验证的领星 HTTP 拉取与活动清单逻辑；将 ISO 周转换为该逻辑需要的周日。
        sunday = date.fromisocalendar(int(week[:4]), int(week[-2:]), 7).isoformat()
        sys.argv = [sys.argv[0], "--week-end", sunday]
        main()
        return

    if args.diagnose:
        diagnose_filters(week)
        return

    raw_rows = []
    for requested_week in (week, prev):
        source_rows = _fetch_bi_week(requested_week)
        print(f"已拉取 {requested_week}：{len(source_rows)} 条 BI 广告原始记录", flush=True)
        for source in source_rows:
            asin = str(_bi_value(source, "platform_sale_code", "平台销售编码")).strip().upper()
            if not asin.startswith("B0"):
                continue
            impressions = _num(_bi_value(source, "impressions_m", "广告展示量"))
            clicks = _num(_bi_value(source, "clicks_m", "广告点击数"))
            spend = _num(_bi_value(source, "spend_m", "广告花费"))
            orders = _num(_bi_value(source, "ad_sales_qty_m", "广告销量"))
            sales = _num(_bi_value(source, "ad_sales_amount_m", "广告销售额"))
            raw_rows.append({
                "年周": _bi_value(source, "yyyyww_Week", "年周") or requested_week,
                "VC1": _bi_value(source, "shop_code", "店铺") or "VC1",
                "业务分类": _bi_value(source, "operation_classification", "业务分类") or "转向器",
                "ASIN": asin, "SKU": _bi_value(source, "sku", "SKU"),
                "广告活动名称": _bi_value(source, "campaign_name2", "广告活动名称"),
                "曝光": impressions, "点击": clicks, "CTR": _rate(clicks, impressions),
                "CVR": _rate(orders, clicks), "广告花费": spend, "广告订单": orders,
                "广告销售额": sales, "ACOS": _rate(spend, sales),
            })

    if not raw_rows:
        raise RuntimeError("广告 BI 查询返回 0 行，未生成空文件。请使用 --diagnose 定位未命中的筛选条件。")

    by_asin = defaultdict(lambda: {"current": defaultdict(float), "previous": defaultdict(float), "campaigns": set(), "skus": set()})
    for row in raw_rows:
        slot = "current" if row["年周"] == week else "previous"
        item = by_asin[row["ASIN"]]
        item["campaigns"].add(str(row["广告活动名称"] or "").strip())
        item["skus"].add(str(row["SKU"] or "").strip())
        for key in ("曝光", "点击", "广告花费", "广告订单", "广告销售额"):
            item[slot][key] += _num(row[key])

    summary_rows = []
    for asin, item in sorted(by_asin.items()):
        current, previous = item["current"], item["previous"]
        summary = {"ASIN": asin, "SKU集合": "、".join(sorted(x for x in item["skus"] if x)), "广告活动名称": "\n".join(sorted(x for x in item["campaigns"] if x))}
        for label, source in (("上周", current), ("上上周", previous)):
            summary.update({f"{label}曝光": source["曝光"], f"{label}点击": source["点击"], f"{label}CTR": _rate(source["点击"], source["曝光"]), f"{label}CVR": _rate(source["广告订单"], source["点击"]), f"{label}广告花费": source["广告花费"], f"{label}广告订单": source["广告订单"], f"{label}广告销售额": source["广告销售额"], f"{label}ACOS": _rate(source["广告花费"], source["广告销售额"]), f"{label}ROAS": round(source["广告销售额"] / source["广告花费"], 2) if source["广告花费"] else ""})
        for metric in ("曝光", "点击", "CTR", "CVR", "广告花费", "广告订单", "广告销售额", "ACOS", "ROAS"):
            summary[f"{metric}环比"] = _change(summary[f"上周{metric}"] or 0, summary[f"上上周{metric}"] or 0)
        summary_rows.append(summary)

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    workbook = Workbook()
    raw_sheet = workbook.active; raw_sheet.title = "BI广告原始数据"
    raw_headers = list(raw_rows[0]) if raw_rows else ["年周", "VC1", "业务分类", "ASIN", "SKU", "广告活动名称", "曝光", "点击", "CTR", "CVR", "广告花费", "广告订单", "广告销售额", "ACOS"]
    raw_sheet.append(raw_headers)
    for row in raw_rows: raw_sheet.append([row.get(key, "") for key in raw_headers])
    summary_sheet = workbook.create_sheet("ASIN广告周汇总")
    summary_headers = list(summary_rows[0]) if summary_rows else ["ASIN", "SKU集合", "广告活动名称"]
    summary_sheet.append(summary_headers)
    for row in summary_rows: summary_sheet.append([row.get(key, "") for key in summary_headers])
    for sheet in (raw_sheet, summary_sheet):
        sheet.freeze_panes = "A2"
        for cell in sheet[1]: cell.font = Font(bold=True, color="FFFFFF"); cell.fill = PatternFill("solid", fgColor="1F4E78")
        for index, header in enumerate([cell.value for cell in sheet[1]], 1): sheet.column_dimensions[get_column_letter(index)].width = 42 if header == "广告活动名称" else 14
    output = Path(args.output_dir) / f"模块A_BI广告原始数据_{week}_vs_{prev}.xlsx"
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    workbook.save(output)
    print(f"原始数据已保存：{output}（原始 {len(raw_rows)} 行；ASIN 汇总 {len(summary_rows)} 行）")


if __name__ == '__main__':
    bi_main()
