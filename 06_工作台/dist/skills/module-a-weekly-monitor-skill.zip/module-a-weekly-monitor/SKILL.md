---
name: xbm-steering-module-a-weekly-monitor
description: 完成周度底层数据拉取、ASIN 预警识别和预警 ASIN × 活动 × 9 指标明细输出。 适用于转向器广告复盘的模块 A 全流程执行。
---

# 模块 A：ASIN 周环比监控

## 目的

完成周度底层数据拉取、ASIN 预警识别和预警 ASIN × 活动 × 9 指标明细输出。

本主技能包含本模块全部脚本子技能及其附属脚本，可作为独立模块整体使用。

## 使用顺序

1. [模块 A 财务原数据拉取](subskills/a-finance-pull/SKILL.md)：拉取模块 A 所需 VC1 财务销量、销售额和 TACOS 底层数据。
2. [模块 A 领星广告周数据拉取](subskills/a-lingxing-weekly-ads/SKILL.md)：批量拉取 14 天广告活动数据并汇总 ASIN 广告指标和活动清单。
3. [模块 A 周环比预警](subskills/a-weekly-alert/SKILL.md)：按单量、销售额和 TACOS 周环比规则计算 ASIN 预警。
4. [模块 A 最终预警明细合并](subskills/a-alert-detail-merge/SKILL.md)：将预警 ASIN 与活动清单、9 项广告指标和环比合并为最终明细。

## 输出

完成后使用模块末一步对应的 `04_分析结果/` 文件作为本模块交付；若主技能需要刷新工作台，再运行“工作台结果同步”子技能。

## 使用约束

- 开始前确定一个项目根目录；对本模块每个子技能使用同一个 `--workspace-root <项目根目录>`，以保证原数据和结果在同一工作区衔接。
- 仅使用资料包 `02_脚本/当前主力/` 的对应脚本，不混用历史参考脚本。
- 拉取前确认 `.env`、数据源权限和上游结果可用；禁止把凭据写入代码或结果。
- 本模块只分析和生成建议。广告、否词、价格或 GitHub 的实际变更必须获得单独授权。
